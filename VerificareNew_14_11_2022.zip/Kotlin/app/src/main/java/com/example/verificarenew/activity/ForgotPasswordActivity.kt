package com.example.verificarenew.activity

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityForgotPasswordBinding
import com.example.verificarenew.util.Utility

class ForgotPasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityForgotPasswordBinding
    private var emailAddress: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_forgot_password)

        if (supportActionBar != null) {
            supportActionBar!!.title = ""
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            supportActionBar!!.setDisplayShowHomeEnabled(true)
        }

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
        }
        return super.onOptionsItemSelected(item)

    }

    fun launchOTPActivity(view: View) {
        emailAddress = binding.edtEmail.getText().toString().trim { it <= ' ' }

        if (Utility.isEmailValid(emailAddress)) {
            val intent = Intent(this, OtpActivity::class.java)
            intent.putExtra("Email", emailAddress)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Enter valid email", Toast.LENGTH_SHORT).show()
        }


    }
}