package com.example.verificarenew.fragmnetlistener

import com.example.verificarenew.model.BatchDetail

interface IFragmentListener {
    fun sendBatchDetails(batchDetail: BatchDetail)
}