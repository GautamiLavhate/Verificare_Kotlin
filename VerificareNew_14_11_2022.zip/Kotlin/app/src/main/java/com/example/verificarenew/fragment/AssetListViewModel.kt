package com.example.verificarenew.fragment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.verificarenew.model.AssetList
import com.example.verificarenew.model.DetailScan
import com.example.verificarenew.model.SubmitBatch
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AssetListViewModel: ViewModel() {

    private val mBatchDetailsMutableLiveData: MutableLiveData<AssetList>? =
        MutableLiveData<AssetList>()

    private val mBatmDeatilResult: MutableLiveData<DetailScan>? = MutableLiveData<DetailScan>()

    private val mSbmmitBatchDetails: MutableLiveData<SubmitBatch>? = MutableLiveData<SubmitBatch>()

    fun submitBatchAll(batchid: String, projId: String, user_id: String): LiveData<SubmitBatch>? {
        if (mSbmmitBatchDetails != null) {
            submitBatch(batchid, projId, user_id)
        }
        return mSbmmitBatchDetails
    }


    fun getAssetDetilas(batchid: String, ProjectId: String): LiveData<AssetList>? {
        if (mBatchDetailsMutableLiveData != null) {
            loadBatchDeatils(batchid, ProjectId)
        }
        return mBatchDetailsMutableLiveData
    }

    private fun loadBatchDeatils(batchid: String, prjId: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getAssetList(batchid, prjId)
        call.enqueue(object : Callback<AssetList?> {
            override fun onResponse(call: Call<AssetList?>, response: Response<AssetList?>) {
                val assetList: AssetList? = response.body()
                if (assetList != null) {
                    mBatchDetailsMutableLiveData!!.setValue(assetList)
                }
            }

            override fun onFailure(call: Call<AssetList?>, t: Throwable) {}
        })
    }


    fun getAssetDetails(
        batch_id: String,
        project_id: String,
        unique_id: String,
        other_batch: String,
        re_verify: String,
        reason: String,
        asset_id: String
    ): LiveData<DetailScan>? {
        if (mBatmDeatilResult != null) {
            loadScanResult(
                batch_id,
                project_id,
                unique_id,
                other_batch,
                re_verify,
                reason,
                asset_id
            )
        }
        return mBatmDeatilResult
    }

    private fun loadScanResult(
        batch_id: String,
        project_id: String,
        unique_id: String,
        other_batch: String,
        re_verify: String,
        reason: String,
        asset_id: String
    ) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getAssetDetail(
            batch_id,
            project_id,
            unique_id,
            other_batch,
            re_verify,
            reason,
            asset_id
        )
        call.enqueue(object : Callback<DetailScan?> {
            override fun onResponse(call: Call<DetailScan?>, response: Response<DetailScan?>) {
                val batchDetails: DetailScan? = response.body()
                if (batchDetails != null) {
                    mBatmDeatilResult!!.setValue(batchDetails)
                }
            }

            override fun onFailure(call: Call<DetailScan?>, t: Throwable) {}
        })
    }

    private fun submitBatch(batchId: String, ProjectId: String, user_id: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.submitBatch(batchId, ProjectId, user_id)
        call?.enqueue(object : Callback<SubmitBatch?> {
            override fun onResponse(call: Call<SubmitBatch?>, response: Response<SubmitBatch?>) {
                val submitBatch: SubmitBatch? = response.body()
                if (submitBatch != null) {
                    mSbmmitBatchDetails!!.setValue(submitBatch)
                }
            }

            override fun onFailure(call: Call<SubmitBatch?>, t: Throwable) {}
        })
    }
}