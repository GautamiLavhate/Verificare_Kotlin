package com.example.verificarenew.fragment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.verificarenew.model.DetailScan
import com.example.verificarenew.model.Details
import com.example.verificarenew.model.Reson
import com.example.verificarenew.model.SendRespose
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailsViewModel: ViewModel() {

    private val mBatchDetailsMutableLiveData: MutableLiveData<DetailScan>? =
        MutableLiveData<DetailScan>()
    private val mResons: MutableLiveData<Reson>? = MutableLiveData<Reson>()
    private val mSendResponse: MutableLiveData<SendRespose>? = MutableLiveData<SendRespose>()
    private val mBatmDeatilResult: MutableLiveData<DetailScan>? = MutableLiveData<DetailScan>()
    private val detailsResult: MutableLiveData<Details>? = MutableLiveData<Details>()

    fun getScanResult(
        ProjectId: String,
        batchId: String,
        qr_code: String,
        other_batch: String,
        re_verify: String, scan_by: String
    ): LiveData<DetailScan>? {
        if (mBatchDetailsMutableLiveData != null) {
            loadScanResult(ProjectId, batchId, qr_code, other_batch, re_verify, scan_by)
        }
        return mBatchDetailsMutableLiveData
    }

    fun getScanResultRFID(
        ProjectId: String,
        batchId: String,
        code: String,
        other_batch: String,
        re_verify: String, scan_by: String
    ): LiveData<DetailScan>? {
        if (mBatchDetailsMutableLiveData != null) {
            loadScanResultRFID(ProjectId, batchId, code, other_batch, re_verify, scan_by)
        }
        return mBatchDetailsMutableLiveData
    }

    fun SubmitAsset(
        asset_id: String,
        project_id: String,
        mode: String,
        qty: String,
        in_use: String,
        batch_id: String,
        user_id: String,
        reason_id: String,
        remark: String,
        in_use_qty: String,
        not_in_use_qty: String,
        not_found_qty: String,
        plant_id: String,
        location_id: String,
        sub_location_id: String
    ): LiveData<SendRespose>? {
        if (mSendResponse != null) {
            SubmitAssetApi(
                asset_id,
                project_id,
                mode,
                qty,
                in_use,
                batch_id,
                user_id,
                reason_id,
                remark,
                in_use_qty,
                not_in_use_qty,
                not_found_qty,
                plant_id,
                location_id,
                sub_location_id
            )
        }
        return mSendResponse
    }

    private fun loadScanResult(
        ProjectId: String,
        batchId: String,
        qr_code: String,
        other_batch: String,
        re_verify: String, scan_by: String
    ) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getScanResult(ProjectId, batchId, qr_code, other_batch, re_verify, scan_by)
        call.enqueue(object : Callback<DetailScan?> {
            override fun onResponse(call: Call<DetailScan?>, response: Response<DetailScan?>) {
                val batchDetails: DetailScan? = response.body()
                if (batchDetails != null) {
                    mBatchDetailsMutableLiveData!!.setValue(batchDetails)
                }
            }

            override fun onFailure(call: Call<DetailScan?>, t: Throwable) {}
        })
    }

    private fun loadScanResultRFID(
        ProjectId: String,
        batchId: String,
        code: String,
        other_batch: String,
        re_verify: String, scan_by: String
    ) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getScanResultRFID(ProjectId, batchId, code, other_batch, re_verify, scan_by)

        call.enqueue(object : Callback<DetailScan?> {
            override fun onResponse(call: Call<DetailScan?>, response: Response<DetailScan?>) {
                val batchDetails: DetailScan? = response.body()
                if (batchDetails != null) {
                    mBatchDetailsMutableLiveData!!.setValue(batchDetails)
                }
            }

            override fun onFailure(call: Call<DetailScan?>, t: Throwable) {}
        })
    }

    fun getAllResons(): LiveData<Reson>? {
        if (mResons != null) {
            loadResons()
        }
        return mResons
    }

    private fun loadResons() {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getAllResons()

        call?.enqueue(object : Callback<Reson?> {
            override fun onResponse(call: Call<Reson?>, response: Response<Reson?>) {
                val re: Reson? = response.body()
                if (re != null) {
                    mResons!!.setValue(re)
                }
            }

            override fun onFailure(call: Call<Reson?>, t: Throwable) {}
        })
    }

    private fun SubmitAssetApi(
        asset_id: String,
        project_id: String,
        mode: String,
        qty: String,
        in_use: String,
        batch_id: String,
        user_id: String,
        reason_id: String,
        remark: String,
        in_use_qty: String,
        not_in_use_qty: String,
        not_found_qty: String,
        plant_id: String,
        location_id: String,
        sub_location_id: String
    ) {

        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.SubmmitAssetOld(
            asset_id,
            project_id,
            mode,
            qty,
            in_use,
            batch_id,
            user_id,
            reason_id,
            remark,
            in_use_qty,
            not_in_use_qty,
            not_found_qty,
            plant_id,
            location_id,
            sub_location_id
        )

        call.enqueue(object : Callback<SendRespose?> {
            override fun onResponse(call: Call<SendRespose?>, response: Response<SendRespose?>) {
                val sendRespose: SendRespose? = response.body()
                if (sendRespose != null) {
                    mSendResponse!!.setValue(sendRespose)
                }
            }

            override fun onFailure(call: Call<SendRespose?>, t: Throwable) {}
        })
    }

    fun getAssetDetails(
        batch_id: String,
        project_id: String,
        unique_id: String,
        other_batch: String,
        re_verify: String,
        reason: String,
        asset_id: String
    ): LiveData<DetailScan>? {
        if (mBatmDeatilResult != null) {
            loadScanResult(
                batch_id,
                project_id,
                unique_id,
                other_batch,
                re_verify,
                reason,
                asset_id
            )
        }
        return mBatmDeatilResult
    }


    fun getDetails(qr_code: String, code: String): LiveData<Details>? {
        if (detailsResult != null) {
            scanResult(qr_code, code)
        }
        return detailsResult
    }

    private fun scanResult(qr_code: String, code: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getDetails(qr_code, code)

        call.enqueue(object : Callback<Details?> {
            override fun onResponse(call: Call<Details?>, response: Response<Details?>) {
                val assetDetails: Details? = response.body()
                if (assetDetails != null) {
                    detailsResult!!.setValue(assetDetails)
                }
            }

            override fun onFailure(call: Call<Details?>, t: Throwable) {}
        })
    }

    private fun loadScanResult(
        batch_id: String,
        project_id: String,
        unique_id: String,
        other_batch: String,
        re_verify: String,
        reason: String,
        asset_id: String
    ) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getAssetDetail(
            batch_id,
            project_id,
            unique_id,
            other_batch,
            re_verify,
            reason,
            asset_id
        )

        call.enqueue(object : Callback<DetailScan?> {
            override fun onResponse(call: Call<DetailScan?>, response: Response<DetailScan?>) {
                val batchDetails: DetailScan? = response.body()
                if (batchDetails != null) {
                    mBatmDeatilResult!!.setValue(batchDetails)
                }
            }

            override fun onFailure(call: Call<DetailScan?>, t: Throwable) {}
        })
    }
}