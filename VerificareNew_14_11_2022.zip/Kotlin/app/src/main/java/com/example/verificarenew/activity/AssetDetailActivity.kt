package com.example.verificarenew.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityAssetDetailBinding

class AssetDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAssetDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_asset_detail)
    }
}