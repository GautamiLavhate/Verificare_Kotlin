package com.example.verificarenew.network

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.view.Gravity
import android.widget.Toast

class CommonClass {
    var activity: Context? = null
    var userSession: SharedPreferences? = null


    fun CommonClass(mContext: Context?) {
        activity = mContext
        userSession = activity!!.getSharedPreferences("Session", 0)
    }

    fun setUserSession(key: String?, value: String?) {
        userSession!!.edit().putString(key, value).apply()
    }

    fun getUserSession(key: String?): String? {
        return userSession!!.getString(key, "")
    }


    fun setToastMessage(msg: String?) {
        val toast = Toast.makeText(activity, msg, Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()
    }

    fun is_internet_connected(): Boolean {
        val connectivity =
            activity!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connectivity != null) {
            val info = connectivity.allNetworkInfo
            if (info != null) for (i in info.indices) if (info[i].state == NetworkInfo.State.CONNECTED) {
                return true
            }
        }
        return false
    }
}