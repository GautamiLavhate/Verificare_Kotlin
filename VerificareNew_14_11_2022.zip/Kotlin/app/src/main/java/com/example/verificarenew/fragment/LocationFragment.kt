package com.example.verificarenew.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.example.verificarenew.R
import com.example.verificarenew.activity.DashboardActivity
import com.example.verificarenew.activity.ScannerActivity
import com.example.verificarenew.adapter.AdapterLocation
import com.example.verificarenew.adapter.AdapterSubLocation
import com.example.verificarenew.databinding.FragmentLocationBinding
import com.example.verificarenew.model.BatchDetails
import com.example.verificarenew.model.Location
import com.example.verificarenew.model.SubLocation
import com.example.verificarenew.network.Constant
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import com.example.verificarenew.network.SessionManager
import com.google.zxing.integration.android.IntentIntegrator
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LocationFragment : Fragment() {

    private lateinit var binding:FragmentLocationBinding
    var adapterLocation: AdapterLocation? = null
    var adapterSubLocation: AdapterSubLocation? = null
    var locationDetails: ArrayList<Location.LocationDetails>? = null
    var subLocationDetails: ArrayList<SubLocation.SubLocationDetails>? = null
    var sessionManager: SessionManager? = null
    var isVisiblee = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_location, container, false)
        sessionManager = SessionManager(context)
        val activity: DashboardActivity? = activity as DashboardActivity?
//        activity?.imgDashBoard?.setImageResource(R.drawable.ic_home_screen)
//        activity?.imgSetBatch?.setImageResource(R.drawable.ic_batch_screen)
//        activity?.imgBatchList?.setImageResource(R.drawable.ic_asset_screen)
//        activity?.imgLocation?.setImageResource(R.drawable.ic_address__3_)
        var constant: Constant = Constant()
        constant.isLocation = true
        constant.isSubLocation = false

        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getBatchdetails(sessionManager?.keY_user_id)

        call.enqueue(object : Callback<BatchDetails?> {
            override fun onResponse(call: Call<BatchDetails?>, response: Response<BatchDetails?>) {
                val batchDetails: BatchDetails? = response.body()
                if (batchDetails != null && batchDetails.getRESPONSESTATUS().equals("1")) {
                    for (i in 0 until batchDetails.getBatchDetails().size) {
                        for (j in 0 until batchDetails.getBatchDetails().get(i).getPermissions().size) {
                            if (batchDetails.getBatchDetails().get(i).getPermissions()
                                    .contains("add")
                            ) {
                                //Toast.makeText(DashboardActivity.this,batchDetails.getBatchDetails().get(i).getPermissions().toString(),Toast.LENGTH_LONG).show();
                                binding.fabAddLocation.show()
                            } else {
                                binding.fabAddLocation.clearAnimation()
                                binding.fabAddLocation.hide()
                            }
                            //
                        }
                    }
                }
            }

            override fun onFailure(call: Call<BatchDetails?>, t: Throwable) {}
        })

        binding.txtLocation.setOnClickListener {
            constant.isLocation = true
            constant.isSubLocation = false
            binding.txtLocation.setTextColor(resources.getColor(R.color.colorPrimary))
            binding.txtSubLocation.setTextColor(resources.getColor(R.color.gray))
            binding.viewLocation.setVisibility(View.VISIBLE)
            binding.viewSubLocation.setVisibility(View.INVISIBLE)
            binding.listViewLocation.setVisibility(View.VISIBLE)
            binding.listViewSubLocation.setVisibility(View.GONE)
        }
        binding.txtSubLocation.setOnClickListener {
            constant.isSubLocation = true
            constant.isLocation = false
            binding.txtSubLocation.setTextColor(resources.getColor(R.color.colorPrimary))
            binding.txtLocation.setTextColor(resources.getColor(R.color.gray))
            binding.viewSubLocation.setVisibility(View.VISIBLE)
            binding.viewLocation.setVisibility(View.INVISIBLE)
            binding.listViewSubLocation.setVisibility(View.VISIBLE)
            binding.listViewLocation.setVisibility(View.GONE)
            getSubLocation(sessionManager!!.keY_new_client_id)
        }
        binding.icInfo.setOnClickListener {
            if (isVisiblee) {
                binding.icQR.setVisibility(View.GONE)
                binding.icRFID.setVisibility(View.GONE)
            } else {
                binding.icQR.setVisibility(View.VISIBLE)
                binding.icRFID.setVisibility(View.VISIBLE)
            }
            isVisiblee = !isVisiblee
        }

        binding.icQR.setOnClickListener {
            SetCurrentBatch.setIsDetailsOnly(true)
            SetCurrentBatch.setType("qr")
            IntentIntegrator(getActivity()).setCaptureActivity(ScannerActivity::class.java)
                .initiateScan()
        }

        binding.icRFID.setOnClickListener {
            SetCurrentBatch.setType("rfid")
            SetCurrentBatch.setIsDetailsOnly(true)
            val dialogFragment: RFIDDialogFragment = RFIDDialogFragment()
            dialogFragment.show(requireActivity().supportFragmentManager, "Test")
        }

        binding.fabAddLocation.setOnClickListener {
            if (constant.isLocation) {
                val fragment: Fragment = AddLocationFragment()
                val fragmentManager = requireActivity().supportFragmentManager
                val fragmentTransaction = fragmentManager.beginTransaction()
                fragmentTransaction.replace(R.id.lay_dashbordView, fragment)
                fragmentTransaction.addToBackStack(null)
                fragmentTransaction.commit()
            } else if (constant.isSubLocation!!) {
                val fragment: Fragment = AddSubLocationFragment()
                val fragmentManager = requireActivity().supportFragmentManager
                val fragmentTransaction = fragmentManager.beginTransaction()
                fragmentTransaction.replace(R.id.lay_dashbordView, fragment)
                fragmentTransaction.addToBackStack(null)
                fragmentTransaction.commit()
            }
        }

        binding.ivBack.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
            val dashboardActivity = getActivity() as DashboardActivity?
            dashboardActivity?.showToolBar()
        }

        Toast.makeText(getContext(),sessionManager!!.keY_client_id,Toast.LENGTH_LONG).show()
        getLocation(sessionManager!!.keY_client_id)
        return binding.root
    }

    fun getLocation(client_id: String?) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getLocations(client_id)
        call.enqueue(object : Callback<Location?> {
            override fun onResponse(call: Call<Location?>, response: Response<Location?>) {
                val location: Location? = response.body()
                if (location != null && location.getrESPONSESTATUS().equals("1")) {
                    binding.txtNodata.setVisibility(View.GONE)
                    locationDetails = location.getLocationDetails()
                    if (activity != null) {
                        adapterLocation = AdapterLocation(activity!!, locationDetails!!)
                        binding.listViewLocation.setAdapter(adapterLocation)
                    }
                } else {
                    binding.listViewLocation.setVisibility(View.GONE)
                    binding.txtNodata.setVisibility(View.VISIBLE)
                    binding.txtNodata.setText(location?.getrESPONSEMSG())
                }
            }

            override fun onFailure(call: Call<Location?>, t: Throwable) {}
        })
    }

    fun getSubLocation(client_id: String?) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getSubLocation(client_id)
        call.enqueue(object : Callback<SubLocation?> {
            override fun onResponse(call: Call<SubLocation?>, response: Response<SubLocation?>) {
                val subLocation = response.body()
                if (subLocation != null && subLocation.getrESPONSESTATUS().equals("1")) {
                    binding.txtNodata.setVisibility(View.GONE)
                    binding.listViewSubLocation.setVisibility(View.VISIBLE)
                    subLocationDetails = subLocation.subLocationDetails
                    adapterSubLocation = AdapterSubLocation(context!!, subLocationDetails!!)
                    binding.listViewSubLocation.setAdapter(adapterSubLocation)
                } else {
                    binding.listViewSubLocation.setVisibility(View.GONE)
                    binding.txtNodata.setVisibility(View.VISIBLE)
                    binding.txtNodata.setText(subLocation!!.getrESPONSEMSG())
                }
            }

            override fun onFailure(call: Call<SubLocation?>, t: Throwable) {}
        })
    }


}