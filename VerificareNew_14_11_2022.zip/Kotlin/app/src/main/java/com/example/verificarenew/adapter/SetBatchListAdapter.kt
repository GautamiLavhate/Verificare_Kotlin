package com.example.verificarenew.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.verificarenew.R
import com.example.verificarenew.model.BatchDetail
import com.example.verificarenew.network.SessionManager

class SetBatchListAdapter(mContext: Context,viewItemList:List<BatchDetail>,mOnClickItem1:OnClickItem) : RecyclerView.Adapter<SetBatchHolder>() {
    private var batchDetailList: List<BatchDetail> = viewItemList
    private val mOnClickItem: OnClickItem = mOnClickItem1


    var context: Context = mContext
    var sessionManager: SessionManager? = null
    interface OnClickItem {
        fun onClick(`object`: Any?)
    }

    fun filterList(filteredData: List<BatchDetail>) {
        batchDetailList = filteredData
        notifyDataSetChanged()
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SetBatchHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.lay_set_item, parent, false)
        val setBatchHolder = SetBatchHolder(itemView)
        context = parent.context
        return setBatchHolder
    }

    override fun onBindViewHolder(setBatchHolder: SetBatchHolder, position: Int) {
        sessionManager = SessionManager(context)
        if (batchDetailList != null) {
            val viewItem = batchDetailList[position]
            setBatchHolder.bind(viewItem, mOnClickItem)
            if (viewItem != null) {
                setBatchHolder.batchId.setText(viewItem.batchName)
                setBatchHolder.batchDate.setText(viewItem.dueDate)
                setBatchHolder.totalQuntity.setText("Total quantity " + viewItem.totalQuantity)
                //Toast.makeText(context,viewItem.getBatchId(),Toast.LENGTH_LONG).show();
                sessionManager?.createBatchDetails(
                    viewItem.projectId,
                    viewItem.clientId,
                    viewItem.plantId,
                    viewItem.batchId,
                    viewItem.batchName,
                    viewItem.dueDate,
                    viewItem.batchStatus,
                    "" + viewItem.totalQuantity
                )
                //                if (batchDetailList.get(position).getPermissions().get(position).contains("scan")){
//                    Constant.scan=true;
//
//                }
                if (viewItem.batchStatus.equals("in_progress")) {
                    setBatchHolder.img.setBackgroundResource(R.drawable.circular_img)
                } else {
                    setBatchHolder.img.setBackgroundResource(R.drawable.circukar_yellow_img)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        var ret = 0
        if (batchDetailList != null) {
            ret = batchDetailList.size
        }
        return ret
    }
}

 class SetBatchHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val batchId: TextView
    val batchDate: TextView
    val totalQuntity: TextView
    val img: ImageView

    fun bind(item: Any?, listener: SetBatchListAdapter.OnClickItem) {
        itemView.setOnClickListener { listener.onClick(item) }
    }

    init {
        batchId = itemView.findViewById(R.id.batchId)
        batchDate = itemView.findViewById(R.id.tvDate)
        totalQuntity = itemView.findViewById(R.id.tvTotal)
        img = itemView.findViewById(R.id.imgIcon)
    }


}