package com.example.verificarenew.activity

import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.PersistableBundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.verificarenew.BuildConfig
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityDashboardBinding
import com.example.verificarenew.fragment.*
import com.example.verificarenew.model.User
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import com.example.verificarenew.network.SessionManager
import com.google.zxing.integration.android.IntentIntegrator
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class DashboardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDashboardBinding
    private var isVisibleMenu = true
    private var menuQR: MenuItem? = null
    private var menuRFID: MenuItem? = null

    private var editor: SharedPreferences.Editor? = null
    private var prefs: SharedPreferences? = null
    var sessionManager: SessionManager? = null
    private var isVisiblee = false


    private var setBatchFragment: SetBatchFragment? = null
    private var user: User? = null

    var RFID = ""
    var code: String? = null

    interface OnBackPress {
        fun onHardKeyBackPress(): Boolean
    }

    private val mOnBackPress: OnBackPress? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_dashboard)

        setSupportActionBar(binding.myToolbar)

        supportActionBar!!.title = "Dashboard"
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        supportActionBar!!.setHomeAsUpIndicator(R.drawable.ic_back_button)
        sessionManager = SessionManager(this@DashboardActivity)
        editor = getSharedPreferences("User", 0).edit()
        prefs = getSharedPreferences("User", 0)

        user = intent.extras!!.getParcelable("user")

        if (user!!.responsestatus.equals("4")) {
            showExitPOP(user!!.responsemsg, false)
        } else if (user!!.responsestatus.equals("5")) {
            showExitPOP(user!!.responsemsg, false)
        }
        binding.fbDashboardScan.setOnClickListener {
            if (isVisiblee) {
                binding.fbDashboardRFID.hide()
                binding.fbDashboardQR.hide()
            } else {
                binding.fbDashboardRFID.show()
                binding.fbDashboardQR.show()
            }
            isVisiblee = !isVisiblee
        }

        binding.fbDashboardRFID.setOnClickListener {
            if (SetCurrentBatch.getInstance().currentBatch != null) {
                SetCurrentBatch.setIsDetailsOnly(false)
                val dialogFragment: RFIDDialogFragment = RFIDDialogFragment()
                dialogFragment.show(supportFragmentManager, "Test")
            } else {
                Toast.makeText(
                    this@DashboardActivity,
                    "Please Set current Batch",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        binding.fbDashboardQR.setOnClickListener {
            if (SetCurrentBatch.getInstance().currentBatch != null) {
                SetCurrentBatch.setIsDetailsOnly(false)
                IntentIntegrator(this@DashboardActivity).setCaptureActivity(ScannerActivity::class.java)
                    .initiateScan()
            } else {
                Toast.makeText(
                    this@DashboardActivity,
                    "Please Set current Batch",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        binding.ivCameraIcon.setOnClickListener {
            val builder = AlertDialog.Builder(this@DashboardActivity)
            builder.setMessage("Choose Scan-Type to proceed.")
                .setTitle("Scan Type")
                .setCancelable(false)
                .setPositiveButton("Barcode") { dialog, id -> }
                .setNegativeButton(
                    "RFID"
                ) { dialog, id ->
                    //rfidDialog();
                }
            val alert = builder.create()
            alert.show()
        }
        addFrag(DashBoardFragment(), DashBoardFragment::class.java.name, false)
        callSetBatchFragment()
        binding.lyBottomView.ivSetBatch.setOnClickListener {
            binding.lyBottomView.imgDashBoard.setImageResource(R.drawable.ic_home_screen)
            binding.lyBottomView.imgSetBatch.setImageResource(R.drawable.ic_select_batch)
            binding.lyBottomView.imgBatchList.setImageResource(R.drawable.ic_asset_screen)
            binding.lyBottomView.imgLocation.setImageResource(R.drawable.ic_address__2_)
            callSetBatchFragment()
        }

        binding.lyBottomView.ivDashBord.setOnClickListener {
            binding.fbDashboardScan.show()
            binding.myToolbar.setVisibility(View.VISIBLE)
            binding.lyBottomView.imgDashBoard.setImageResource(R.drawable.ic_mask_group_215)
            binding.lyBottomView.imgSetBatch.setImageResource(R.drawable.ic_batch_screen)
            binding.lyBottomView.imgBatchList.setImageResource(R.drawable.ic_asset_screen)
            binding.lyBottomView.imgLocation.setImageResource(R.drawable.ic_address__2_)
            supportFragmentManager.popBackStack()
            addFrag(DashBoardFragment(), DashBoardFragment::class.java.name, false)
        }

        binding.lyBottomView.ivBatchList.setOnClickListener {
            binding.lyBottomView.imgDashBoard.setImageResource(R.drawable.ic_home_screen)
            binding.lyBottomView.imgSetBatch.setImageResource(R.drawable.ic_batch_screen)
            binding.lyBottomView.imgBatchList.setImageResource(R.drawable.ic_mask_group_225)
            binding.lyBottomView.imgLocation.setImageResource(R.drawable.ic_address__2_)
            callAssetListFragment()
        }

        binding.lyBottomView.ivLocation.setOnClickListener {
            binding.lyBottomView.imgDashBoard.setImageResource(R.drawable.ic_home_screen)
            binding.lyBottomView.imgSetBatch.setImageResource(R.drawable.ic_batch_screen)
            binding.lyBottomView.imgBatchList.setImageResource(R.drawable.ic_asset_screen)
            binding.lyBottomView.imgLocation.setImageResource(R.drawable.ic_address__3_)
            binding.fbDashboardRFID.hide()
            binding.fbDashboardQR.hide()
            callLocationFragment()
        }
    }
    private fun callSetBatchFragment() {
        binding.fbDashboardScan.show()
        supportFragmentManager.popBackStack()
        setBatchFragment = SetBatchFragment()
        val b = Bundle()
        b.putParcelable("user", user)
        setBatchFragment!!.setArguments(b)
        addFrag(setBatchFragment, SetBatchFragment::class.java.name, true)
        binding.myToolbar.setVisibility(View.GONE)
    }
    fun callAssetListFragment() {
        binding.fbDashboardScan.show()
        binding.myToolbar.setVisibility(View.GONE)
        supportFragmentManager.popBackStack()
        addFrag(AssetListFragment(), AssetListFragment::class.java.getName(), true)
    }

    fun callLocationFragment(){
        binding.fbDashboardScan.hide()
        binding.myToolbar.setVisibility(View.GONE)
        supportFragmentManager.popBackStack()
        addFrag(LocationFragment(), LocationFragment::class.java.getName(), true)
    }

    private fun callAddLocationFragment() {
        binding.myToolbar.setVisibility(View.GONE)
        supportFragmentManager.popBackStack()
        addFrag(AddLocationFragment(), AddLocationFragment::class.java.name, true)
    }

    private fun callAddSubLocationFragment() {
        binding.myToolbar.setVisibility(View.GONE)
        supportFragmentManager.popBackStack()
        addFrag(AddSubLocationFragment(), AddSubLocationFragment::class.java.name, true)
    }

    fun showToolBar() {
        binding.myToolbar.setVisibility(View.VISIBLE)
    }

    private fun getFrag(tag: String): Fragment? {
        return supportFragmentManager.findFragmentByTag(tag)
    }

    fun addFrag(fragment: Fragment?, Tag: String?, isAddTobackStack: Boolean) {
        val fragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()
        transaction.add(R.id.lay_dashbordView, fragment!!, Tag)
        if (isAddTobackStack) transaction.addToBackStack(Tag)
        transaction.commit()
    }

    fun addFrag(fragment: Fragment?, Tag: String?) {
        val fragmentManager = this.supportFragmentManager
        val transaction = fragmentManager.beginTransaction()
        transaction.add(R.id.fullScreenView, fragment!!, Tag)
        transaction.addToBackStack(Tag)
        transaction.commit()
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        menuQR = menu.findItem(R.id.action_scan_qr)
        menuRFID = menu.findItem(R.id.action_scan_rfid)
        if (isVisibleMenu) {
            menuQR?.setVisible(false)
            menuRFID?.setVisible(false)
        } else {
            menuQR?.setVisible(true)
            menuRFID?.setVisible(true)
        }
        return true
    }

    //    @Override
    //    public boolean onPrepareOptionsMenu(Menu menu) {
    //        getMenuInflater().inflate(R.menu.main_menu, menu);
    //        menuQR = menu.findItem(R.id.action_scan_qr);
    //        menuRFID = menu.findItem(R.id.action_scan_rfid);
    //        return true;
    //    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return when (id) {
            R.id.action_profile -> {
                val i = Intent(this@DashboardActivity, ProfileActivity::class.java)
                startActivity(i)
                true
            }
            R.id.action_share_app -> {
                shareApp()
                true
            }
            R.id.action_about_us -> {
                val intent = Intent(this, AboutUsActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.action_info -> {
                isVisibleMenu = !isVisibleMenu
                invalidateOptionsMenu()
                true
            }
            android.R.id.home -> {
                showExitPOP("", true)
                true
            }
            R.id.action_setting -> {
                val settingDialogFragment: SettingDialogFragment =
                    SettingDialogFragment()
                settingDialogFragment.show(supportFragmentManager, "Test")
                true
            }
            R.id.action_scan_qr -> {
                isVisibleMenu = !isVisibleMenu
                SetCurrentBatch.setIsDetailsOnly(true)
                SetCurrentBatch.setType("qr")
                IntentIntegrator(this@DashboardActivity).setCaptureActivity(ScannerActivity::class.java)
                    .initiateScan()
                true
            }
            R.id.action_scan_rfid -> {
                isVisibleMenu = !isVisibleMenu
                SetCurrentBatch.setType("rfid")
                SetCurrentBatch.setIsDetailsOnly(true)
                val dialogFragment: RFIDDialogFragment = RFIDDialogFragment()
                dialogFragment.show(supportFragmentManager, "Test")
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun shareApp() {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "VERIFICARE")
            var shareMessage = "\nLet me recommend you this application\n\n"
            shareMessage =
                """
            ${shareMessage}https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}
            
            
            """.trimIndent()
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
            startActivity(Intent.createChooser(shareIntent, "choose one"))
        } catch (e: Exception) {
        }
    }

    override fun onBackPressed() {

        if (mOnBackPress != null) {
            mOnBackPress.onHardKeyBackPress()
        } else {
            binding.myToolbar.setVisibility(View.VISIBLE)
        }
        if (supportFragmentManager.backStackEntryCount < 1) showExitPOP("", true) else {
            super.onBackPressed()
        }
    }

    private fun ExitApp() {
        CurrentUser.getInstance().setCurrentUser(null)
        SetCurrentBatch.getInstance().setCurrentBatchDetails(null)
        finish()
    }
    private fun clearStack(name: String) {
        val fm = supportFragmentManager
        fm.popBackStack(name, FragmentManager.POP_BACK_STACK_INCLUSIVE)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        //We will get scan results here
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        //check for null
        //check for null
        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(this, "Scan Cancelled", Toast.LENGTH_LONG).show()
                //callView(2);
            } else {
                //callView(1);
                //show dialogue with result
                try {
                    val arrayList: List<String> =
                        ArrayList(Arrays.asList(*result.contents.split("\\|").toTypedArray()))
                    code = arrayList[0]
                    callView(1, code)
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
                // 7 1100 VW14000036-0-0 | Computers | SAP No VW14000036 | Lasear jet multi functional printer | Qty 1
            }
        } else {
            // This is important, otherwise the result will not be passed to the fragment

            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    fun callView(event: Int, code: String?) {
        when (event) {
            1 -> if (SetCurrentBatch.getIsDetailsOnly()) {
                Handler().postDelayed({
                    runOnUiThread {
                        val intent = Intent(baseContext, AssetDetailActivity::class.java)
                        intent.putExtra("Code", code)
                        startActivity(intent)
                    }
                }, 10)
            } else {
                viewHolder()
            }
            2 -> Handler().postDelayed({ callAssetListFragment() }, 10)
        }
    }

    fun viewHolder() {
        Handler().postDelayed({
            runOnUiThread { // mToolbar.setVisibility(View.GONE);
                callDetailActivity()
            }
        }, 10)
    }

    fun callDetailActivity() {
        val i = Intent(this, DetailsViewActivity::class.java)
        i.putExtra("user", user)
        i.putExtra("Code", code)
        startActivity(i)
    }

    fun showExitPOP(text: String?, isShowTwoButton: Boolean): Dialog? {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.lay_exit_dialog)
        val test = dialog.findViewById<TextView>(R.id.textmsg)
        if (!isShowTwoButton) {
            test.text = text
        }
        val btnYes = dialog.findViewById<Button>(R.id.btnYes)
        val btnNo = dialog.findViewById<Button>(R.id.btnNo)
        if (isShowTwoButton) {
            btnNo.visibility = View.VISIBLE
            btnNo.text = "No"
            btnYes.visibility = View.VISIBLE
            btnYes.text = "Yes"
        } else {
            btnNo.visibility = View.GONE
            btnYes.visibility = View.VISIBLE
            btnYes.text = "Ok"
        }
        btnNo.setOnClickListener { dialog.dismiss() }
        btnYes.setOnClickListener { //ExitApp();
            val android_id = Settings.Secure.getString(
                this@DashboardActivity.contentResolver,
                Settings.Secure.ANDROID_ID
            )
            logout(sessionManager!!.getKEY_user_id(), android_id) //"12345678999999"
            dialog.dismiss()
        }
        dialog.show()
        return dialog
    }

    private fun rfidDialog() {
        val dialog = Dialog(this@DashboardActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.activity_rfid)
        val window = dialog.window
        window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCanceledOnTouchOutside(false)
        val text = dialog.findViewById<View>(R.id.text) as EditText
        text.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s.length > 9) {
                    val data = text.text.toString()
                    Toast.makeText(applicationContext, "ID $data", Toast.LENGTH_LONG).show()
                    RFID = ""
                    RFID = s.toString()
                    dialog.dismiss()
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })
        dialog.show()
    }

    private fun logout(user_id: String, device_id: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.logout(user_id, device_id)
        call.enqueue(object : Callback<User?> {
            override fun onResponse(call: Call<User?>, response: Response<User?>) {
                val user = response.body()
                if (user != null && user.responsestatus.equals("1")) {
                    Toast.makeText(
                        this@DashboardActivity,
                        "" + user.responsemsg,
                        Toast.LENGTH_SHORT
                    ).show()
                    ExitApp()
                } else {
                    Toast.makeText(
                        this@DashboardActivity,
                        "" + user!!.responsemsg,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<User?>, t: Throwable) {}
        })
    }

    fun getPreference(key: String): Boolean {
        return if (key.equals("sound", ignoreCase = true)) {
            prefs!!.getBoolean(key, true)
        } else {
            prefs!!.getBoolean(key, false)
        }
    }

    fun setPreference(key: String?, value: Boolean?) {
        editor!!.putBoolean(key, value!!)
        editor!!.commit()
    }


}