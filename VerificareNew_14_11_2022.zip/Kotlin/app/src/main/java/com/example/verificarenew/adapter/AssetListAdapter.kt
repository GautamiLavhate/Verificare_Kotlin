package com.example.verificarenew.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.verificarenew.R
import com.example.verificarenew.model.AssetList

class AssetListAdapter(assetsDetailList1: List<AssetList.AssetsDetail>,mOnItemClickListener1: OnItemClickListener): RecyclerView.Adapter<AssetListHolder>() {
    private var assetsDetailList: List<AssetList.AssetsDetail> = assetsDetailList1
    private val mOnItemClickListener: OnItemClickListener = mOnItemClickListener1
    interface OnItemClickListener {
        fun onItemClick(`object`: Any?)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AssetListHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.lay_asset_list, parent, false)
        return AssetListHolder(itemView)
    }

    override fun onBindViewHolder(assetListHolder: AssetListHolder, position: Int) {
        if (assetsDetailList != null) {
            val viewItem: AssetList.AssetsDetail = assetsDetailList.get(position)
            assetListHolder.bind(viewItem, mOnItemClickListener)
            if (viewItem != null) {
                viewItem.getAssetNumber()
                // Set car item title.
                assetListHolder.textView.setText(viewItem.getAssetNumber())
                if (viewItem.getIsScan().equals("True")) {
                    assetListHolder.imagScan.setBackgroundResource(R.drawable.ic_scan_entry)
                } else {
                    assetListHolder.imagScan.setBackgroundResource(R.drawable.ic_manual_entry)
                }
                if (viewItem.getAssetStatus().equals("pending")) {
                    assetListHolder.statusImage
                        .setBackgroundResource(R.drawable.circukar_yellow_img)
                } else {
                    assetListHolder.statusImage.setBackgroundResource(R.drawable.circular_img)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        var ret = 0
        if (assetsDetailList != null) {
            ret = assetsDetailList.size
        }
        return ret
    }

    fun filterList(filteredData: List<AssetList.AssetsDetail>) {
        assetsDetailList = filteredData
        notifyDataSetChanged()
    }
}


class AssetListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val textView: TextView
    val imagScan: ImageView
    val statusImage: ImageView

    fun bind(item: Any?, listener: AssetListAdapter.OnItemClickListener) {
        imagScan.setOnClickListener { listener.onItemClick(item) }
    }

    init {
        textView = itemView.findViewById(R.id.assetId)
        imagScan = itemView.findViewById(R.id.ivTypeOfScanner)
        statusImage = itemView.findViewById(R.id.imgStatus)
    }
}