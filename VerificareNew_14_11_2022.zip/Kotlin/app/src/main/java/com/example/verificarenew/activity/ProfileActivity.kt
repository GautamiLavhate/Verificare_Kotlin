package com.example.verificarenew.activity

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityProfileBinding
import com.example.verificarenew.fragment.ProfileDetailsFragment
import com.example.verificarenew.fragment.SetCurrentBatch
import com.example.verificarenew.model.User
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import com.example.verificarenew.network.SessionManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    var sessionManager: SessionManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_profile)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        supportActionBar!!.setHomeAsUpIndicator(R.drawable.ic_back_button)

        sessionManager = SessionManager(this@ProfileActivity)
        launchProfileFragment()
    }

    fun setTitle(title: String?) {
        if (title != null) {
            supportActionBar!!.title = title
        }
    }

    private fun launchProfileFragment() {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.container_profile, ProfileDetailsFragment())
        fragmentTransaction.commit()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    fun showExitPOP(text: String?, isShowTwoButton: Boolean): Dialog? {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.lay_exit_dialog)
        val test = dialog.findViewById<TextView>(R.id.textmsg)
        test.text = text
        val btnYes = dialog.findViewById<Button>(R.id.btnYes)
        val btnNo = dialog.findViewById<Button>(R.id.btnNo)
        if (isShowTwoButton) {
            btnNo.visibility = View.VISIBLE
            btnNo.text = "No"
            btnYes.visibility = View.VISIBLE
            btnYes.text = "Yes"
        } else {
            btnNo.visibility = View.GONE
            btnYes.visibility = View.VISIBLE
            btnYes.text = "Ok"
        }
        btnNo.setOnClickListener { dialog.dismiss() }
        btnYes.setOnClickListener {
            val android_id = Settings.Secure.getString(
                this@ProfileActivity.contentResolver,
                Settings.Secure.ANDROID_ID
            )
            logout(sessionManager!!.keY_user_id, android_id)
            dialog.dismiss()
        }
        dialog.show()
        return dialog
    }

    fun ExitApp() {
        CurrentUser.getInstance().setCurrentUser(null)
        SetCurrentBatch.getInstance().setCurrentBatchDetails(null)
        finishAffinity()
        val intent = Intent(this@ProfileActivity, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    private fun logout(user_id: String, device_id: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.logout(user_id,device_id)
        call.enqueue(object : Callback<User?> {
            override fun onResponse(call: Call<User?>, response: Response<User?>) {
                val user: User? = response.body()
                if (user != null && user.getRESPONSESTATUS().equals("1")) {
                    Toast.makeText(
                        this@ProfileActivity,
                        "" + user.getRESPONSEMSG(),
                        Toast.LENGTH_SHORT
                    ).show()
                    ExitApp()
                } else {
                    Toast.makeText(
                        this@ProfileActivity,
                        "" + user?.getRESPONSEMSG(),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<User?>, t: Throwable) {}
        })
    }
}