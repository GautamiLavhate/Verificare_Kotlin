package com.example.verificarenew.activity

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.CountDownTimer
import android.view.MenuItem
import android.view.View
import android.view.Window
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivitySetPasswordBinding

class SetPasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySetPasswordBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_set_password)
        if (supportActionBar != null) {
            supportActionBar!!.title = ""
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            supportActionBar!!.setDisplayShowHomeEnabled(true)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    fun showDialog(context: Context?, msg1: String?, msg2: String?) {
        val dialog = Dialog(context!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_custom)
        val message2 = dialog.findViewById<TextView>(R.id.diMessage2)
        message2.visibility = View.VISIBLE
        message2.text = msg2
        dialog.show()
        object : CountDownTimer(2500, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                //igonre
            }

            override fun onFinish() {
                dialog.dismiss()
            }
        }.start()
    }

    fun changePassword(view: View) {
        showDialog(this, null, "Password changed Successfully")
    }
}