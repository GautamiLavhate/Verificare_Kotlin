package com.example.verificarenew.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.verificarenew.R
import com.example.verificarenew.model.Dashboard

class RecyclerHorizantalViewDataAdapter(viewItemList1 : List<Dashboard.DashboardDetails.Date> ): RecyclerView.Adapter<CustomRecyclerViewHolder>() {
    private val viewItemList: List<Dashboard.DashboardDetails.Date> = viewItemList1
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomRecyclerViewHolder {
        // Get LayoutInflater object.

        // Get LayoutInflater object.
        val layoutInflater = LayoutInflater.from(parent.context)
        // Inflate the RecyclerView item layout xml.
        // Inflate the RecyclerView item layout xml.
        val itemView =
            layoutInflater.inflate(R.layout.lay_horizantal_list_iteam, parent, false)

        // Create and return our customRecycler View Holder object.

        // Create and return our customRecycler View Holder object.
        return CustomRecyclerViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: CustomRecyclerViewHolder, position: Int) {
        if (viewItemList != null) {
            // Get car item dto in list.
            val viewItem = viewItemList[position]
            if (viewItem != null) {
                // Set car item title.
                Log.d("TAG", "onBindViewHolder: " + viewItem.date)
                val dates: List<String> = viewItem.date.split("-")
                holder.date?.setText("" + dates[2])
                holder.month?.setText("" + returnMonth(dates[1]))
                holder.totalCount?.setText("" + viewItem.count)
            }
        }
    }

    override fun getItemCount(): Int {
        var ret = 0
        if (viewItemList != null) {
            ret = viewItemList.size
        }
        return ret
    }

    private fun returnMonth(no: String): String? {
        var month = ""
        when (no) {
            "01" -> month = "Jan"
            "02" -> month = "Feb"
            "03" -> month = "Mar"
            "04" -> month = "Apr"
            "05" -> month = "May"
            "06" -> month = "June"
            "07" -> month = "July"
            "08" -> month = "Aug"
            "09" -> month = "Sept"
            "10" -> month = "Oct"
            "11" -> month = "Nov"
            "12" -> month = "Dec"
        }
        return month
    }
}

class CustomRecyclerViewHolder(itemView: View?) :
    RecyclerView.ViewHolder(itemView!!) {
    var month: TextView? = null
    var totalCount: TextView? = null
    var date: TextView? = null

    init {
        if (itemView != null) {
            month = itemView.findViewById(R.id.month)
            totalCount = itemView.findViewById(R.id.tvTotalCount)
            date = itemView.findViewById(R.id.tvDate)
        }
    }
}