package com.example.verificarenew.network

class Constant {
    public  var isLocation = false
    var isSubLocation:kotlin.Boolean? = false
    var isAddLocation = false
    var isAddSubLocation:kotlin.Boolean? = false
    var scan = false

    //    public static String Base_url="https://applexinfotech.com/fav/";
    var Base_url = "https://verificare.levare.co.in/"
    var SUBMIT_DETAIL_URL = "https://applexinfotech.com/fav/api/app_submit_details.php"
}