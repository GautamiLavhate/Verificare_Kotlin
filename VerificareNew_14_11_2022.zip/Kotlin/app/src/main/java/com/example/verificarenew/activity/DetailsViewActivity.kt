package com.example.verificarenew.activity

import android.app.Dialog
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.PersistableBundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityDetailsViewBinding
import com.example.verificarenew.fragment.DetailsViewModel
import com.example.verificarenew.model.*
import com.example.verificarenew.network.Constant
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import com.example.verificarenew.network.SessionManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.*
import java.text.SimpleDateFormat
import java.util.*


class DetailsViewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailsViewBinding
    private var mViewModel: DetailsViewModel? = null
    private val EVENT = 0
    private var code: String? = null
    private var dialog: Dialog? = null
    private val assetDetails: DetailScan.AssetDetails? = null
    private val batchDetail: BatchDetail? = null
    private var mUser: User? = null

    private var mDetailsViewActivity: DetailsViewActivity? = null

    private val detailsReson: ArrayList<Reson.ReasonDetail>? = null
    private var isFromAsset = false
    private  var isManulScan:Boolean = false

    private var RegionScan = ""


    private var type: String? = null

    var plantDetails: ArrayList<Plant.PlantDetails>? = null
    var locationDetails: ArrayList<Location.LocationDetails>? = null
    var subLocationDetails: ArrayList<SubLocation.SubLocationDetails>? = null
    var strPlantId: String? =
        null
    var strLocationName:String? = null
    var strLocationId:String? = null
    var strSubLocation:String? = null
    var sessionManager: SessionManager? = null
    var selectedLocation = 0
    var selectedSubLocation:Int = 0
    var selectedPlantId:Int = 0


    var assetId: String? = null
    var bitmapFinal: Bitmap? =
        null
    var bitmapFinal2:Bitmap? = null
    var bitmapFinal3:Bitmap? = null
    var bitmapFinal4:Bitmap? = null
    var bitmapFinal5:Bitmap? = null
    var arrayListImageId: ArrayList<MultipartBody.Part>? = null
    var strImageId1: String? =
        null
    var strImageId2:kotlin.String? = null
    var strImageId3:kotlin.String? = null
    var strImageId4:kotlin.String? = null
    var strImageId5:kotlin.String? = null

    var Path1 =
        ""
    var Path2:kotlin.String? = ""
    var Path3:kotlin.String? = ""
    var Path4:kotlin.String? = ""
    var Path5:kotlin.String? = ""
    private var PATH: String? =
        null
    private  var PATH2:kotlin.String? = null
    private  var PATH3:kotlin.String? = null
    private  var PATH4:kotlin.String? = null
    private  var PATH5:kotlin.String? = null

    // Define the pic id
    private val take_a_photo1 = 61
    private val take_a_photo2 = 62
    private val take_a_photo3 = 63
    private val take_a_photo4 = 64
    private val take_a_photo5 = 65

    private val edit_take_a_photo1 = 66
    private val edit_take_a_photo2 = 67
    private val edit_take_a_photo3 = 68
    private val edit_take_a_photo4 = 69
    private val edit_take_a_photo5 = 70

    var filePath1 = ""

    var files: List<Uri> = ArrayList()
    var image_id: List<String> = ArrayList()

    var fileList: List<MultipartBody.Part> = ArrayList()
    var imageIdList: List<MultipartBody.Part> = ArrayList()

    // image list

    // image list
    var constant: Constant = Constant()
    var Base_url: String = constant.Base_url
    var strImage1 =
        ""
    var strImage2:kotlin.String? = ""

    var strImage3:kotlin.String? = ""
    var strImage4:kotlin.String? = ""
    var strImage5:kotlin.String? = ""
    var strOldImage1 =
        ""
    var strOldImage2:kotlin.String? = ""
    var strOldImage3:kotlin.String? = ""
    var strOldImage4:kotlin.String? = ""
    var strOldImage5:kotlin.String? = ""

    private val REQUEST_CODE_ASK_PERMISSIONS = 123

    var bottomSheetDialog1: BottomSheetDialog? =
        null
    var bottomSheetDialog2:BottomSheetDialog? = null
    var bottomSheetDialog3:BottomSheetDialog? = null
    var bottomSheetDialog4:BottomSheetDialog? = null
    var bottomSheetDialog5:BottomSheetDialog? = null

    var demoFile: File? = null

    var bitmap: Bitmap? = null
    private var destination: File? = null
    var is1: InputStream? = null
    var is2: InputStream? = null
    var is3: InputStream? = null
    var is4: InputStream? = null
    var is5: InputStream? = null
    var width = 0
    var strImageArray = "0"

    var straddimg1 =
        "0"
    var straddimg2:kotlin.String? = "0"
    var straddimg3:kotlin.String? = "0"
    var straddimg4:kotlin.String? = "0"
    var straddimg5:kotlin.String? = "0"
    var boolimg1 =
        false
    var boolimg2:kotlin.Boolean? = false
    var boolimg3:kotlin.Boolean? = false
    var boolimg4:kotlin.Boolean? = false
    var boolimg5:kotlin.Boolean? = false
    var boolValidate = false
    var imageArray: ArrayList<String>? = null

    private var progressDialog: ProgressDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_details_view)

        progressDialog = ProgressDialog(this)
        progressDialog?.setMessage("Please wait")
        progressDialog?.setCancelable(false)
        mViewModel = ViewModelProviders.of(this).get(DetailsViewModel::class.java)
        sessionManager = SessionManager(this@DetailsViewActivity)
        mDetailsViewActivity = this
        arrayListImageId = ArrayList()
        imageArray = ArrayList()
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        width = displayMetrics.widthPixels

        binding.layDetailFragment.spConditionBase.selectedItem

        //  showPOP = true;
        mUser = CurrentUser.getInstance().user
        if (mUser != null) {
            Log.d("User", "onCreate: " + mUser?.getRESPONSEMSG())
        }
        val intent = intent
        if (intent != null) {
            code = intent.getStringExtra("Code")
            type = intent.getStringExtra("Type")
            isFromAsset = intent.getBooleanExtra("isFromAsset", false)
            isManulScan = intent.getBooleanExtra("isManual", false)
            RegionScan = intent.getStringExtra("r")!!
        }

        binding.back.setOnClickListener {
            finish()
        }
    }

    override fun onPostCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onPostCreate(savedInstanceState, persistentState)
    }

    private fun SubmmitAssetApi() {
        if (assetDetails != null) {
            var text = binding.layDetailFragment.spConditionBase.getSelectedItem() as String
            text = if (text.equals("In Use", ignoreCase = true)) {
                "yes"
            } else if (text.equals("-Select Condition-", ignoreCase = true)) {
                ""
            } else {
                "no"
            }
            val use = if (isFromAsset) binding.layDetailFragment.edInUse.getEditableText().toString() else "0"
            val notInuse = if (isFromAsset) binding.layDetailFragment.edNotInUse.getEditableText().toString() else "0"
            val notF = if (isFromAsset) binding.layDetailFragment.edNotFound.getEditableText().toString() else "0"
            val post: Int = binding.layDetailFragment.spSelctReson.getSelectedItemPosition()
            var rgId = ""
            if (binding.layDetailFragment.spSelctReson.getSelectedItemPosition() == 0) {
                rgId = "0"
            } else {
                if (post != 0) {
                    val reasonDetail: Reson.ReasonDetail = detailsReson!![post - 1]
                    rgId = reasonDetail.getReasonId()
                }
            }
            //Please connect device
            var mode = ""
            mode = if (isFromAsset || isManulScan) {
                //mode = mode + "manual";
                mode + "auto"
            } else {
                mode + "auto"
            }
            if (isFromAsset == false && isManulScan == false && text.isEmpty() && text == "") {
                Toast.makeText(mDetailsViewActivity, "Please Select condition", Toast.LENGTH_SHORT)
                    .show()
                return
            }
            val BookQT = assetDetails.bookQty.toInt()
            var useint = 0
            var notuse = 0
            var notFint = 0
            if (!use.isEmpty()) {
                useint = use.toInt()
            }
            if (!notInuse.isEmpty()) {
                notuse = notInuse.toInt()
            }
            if (!notF.isEmpty()) {
                notFint = notF.toInt()
            }
            if (isFromAsset) {
                val total = useint + notuse + notFint
                if (BookQT > total) {
                    Toast.makeText(
                        mDetailsViewActivity,
                        " total of use,not in use and not found must be greater than book Quantity.",
                        Toast.LENGTH_SHORT
                    ).show()
                    return
                }
            }
            if (mode == "auto") {
                if (text.isEmpty()) {
                    Toast.makeText(mDetailsViewActivity, "Select condition", Toast.LENGTH_SHORT)
                        .show()
                    return
                }
            }
            if (strPlantId.equals("0", ignoreCase = true)) {
                Toast.makeText(
                    this@DetailsViewActivity,
                    "Please confirm location!",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                val rbasset_id =
                    RequestBody.create(MediaType.parse("multipart/form-data"), assetDetails.assetId)
                val rbproject_id = RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    batchDetail!!.projectId
                )
                val rbmode = RequestBody.create(MediaType.parse("multipart/form-data"), mode)
                val rbqty = RequestBody.create(MediaType.parse("multipart/form-data"), "1")
                val rbin_use = RequestBody.create(MediaType.parse("multipart/form-data"), text)
                val rbbatch_id =
                    RequestBody.create(MediaType.parse("multipart/form-data"), batchDetail.batchId)
                val rbuser_id = RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    mUser!!.profileDetails.userId
                )
                val rbreason_id = RequestBody.create(MediaType.parse("multipart/form-data"), rgId)
                val rbremark: RequestBody = RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.layDetailFragment.EdRemark.getText().toString()
                )
                val rbin_use_qty = RequestBody.create(MediaType.parse("multipart/form-data"), use)
                val rbnot_in_use_qty =
                    RequestBody.create(MediaType.parse("multipart/form-data"), notInuse)
                val rbnot_found_qty =
                    RequestBody.create(MediaType.parse("multipart/form-data"), notF)
                val rbplant_id =
                    RequestBody.create(MediaType.parse("multipart/form-data"), strPlantId)
                val rblocation_id = RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    selectedLocation.toString()
                )
                val rbsub_location_id = RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    selectedSubLocation.toString()
                )
                val rbold_image1 =
                    RequestBody.create(MediaType.parse("multipart/form-data"), strOldImage1)
                val rbold_image2 =
                    RequestBody.create(MediaType.parse("multipart/form-data"), strOldImage2)
                val rbold_image3 =
                    RequestBody.create(MediaType.parse("multipart/form-data"), strOldImage3)
                val rbold_image4 =
                    RequestBody.create(MediaType.parse("multipart/form-data"), strOldImage4)
                val rbold_image5 =
                    RequestBody.create(MediaType.parse("multipart/form-data"), strOldImage5)

                //IMAGE1 START
                val image1 = PATH
                val imageFile1: RequestBody
                val body1: MultipartBody.Part
                if (image1 != null) {
                    var imageBytes: ByteArray? = ByteArray(0)
                    val file = File(image1)
                    /* File file = new File(Fiximge,Fiximge);*/
                    val Filenale: String
                    Filenale = if (file.name.contains(".png")) {
                        file.name
                    } else {
                        file.name + ".png"
                    }
                    try {
                        imageBytes = getBytes(is1, image1, file)
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                    imageFile1 =
                        RequestBody.create(MediaType.parse("multipart/form-data"), imageBytes)
                    body1 = MultipartBody.Part.createFormData("image1", Filenale, imageFile1)
                } else {
                    imageFile1 = RequestBody.create(MediaType.parse("multipart/form-data"), "")
                    body1 = MultipartBody.Part.createFormData("image1", "", imageFile1)
                }
                //IMAGE1 END

                //IMAGE2 START
                val image2 = PATH2
                val imageFile2: RequestBody
                val body2: MultipartBody.Part
                if (image2 != null) {
                    var imageBytes: ByteArray? = ByteArray(0)
                    val file = File(image2)
                    /* File file = new File(Fiximge,Fiximge);*/
                    val Filenale: String
                    Filenale = if (file.name.contains(".png")) {
                        file.name
                    } else {
                        file.name + ".png"
                    }
                    try {
                        imageBytes = getBytes(is2, image2, file)
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                    imageFile2 =
                        RequestBody.create(MediaType.parse("multipart/form-data"), imageBytes)
                    body2 = MultipartBody.Part.createFormData("image2", Filenale, imageFile2)
                } else {
                    imageFile2 = RequestBody.create(MediaType.parse("multipart/form-data"), "")
                    body2 = MultipartBody.Part.createFormData("image2", "", imageFile2)
                }
                //IMAGE2 END

                //IMAGE3 START
                val image3 = PATH3
                val imageFile3: RequestBody
                val body3: MultipartBody.Part
                if (image3 != null) {
                    var imageBytes: ByteArray? = ByteArray(0)
                    val file = File(image3)
                    /* File file = new File(Fiximge,Fiximge);*/
                    val Filenale: String
                    Filenale = if (file.name.contains(".png")) {
                        file.name
                    } else {
                        file.name + ".png"
                    }
                    try {
                        imageBytes = getBytes(is3, image3, file)
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                    imageFile3 =
                        RequestBody.create(MediaType.parse("multipart/form-data"), imageBytes)
                    body3 = MultipartBody.Part.createFormData("image3", Filenale, imageFile3)
                } else {
                    imageFile3 = RequestBody.create(MediaType.parse("multipart/form-data"), "")
                    body3 = MultipartBody.Part.createFormData("image3", "", imageFile3)
                }
                //IMAGE3 END

                //IMAGE4 START
                val image4 = PATH4
                val imageFile4: RequestBody
                val body4: MultipartBody.Part
                if (image4 != null) {
                    var imageBytes: ByteArray? = ByteArray(0)
                    val file = File(image4)
                    /* File file = new File(Fiximge,Fiximge);*/
                    val Filenale: String
                    Filenale = if (file.name.contains(".png")) {
                        file.name
                    } else {
                        file.name + ".png"
                    }
                    try {
                        imageBytes = getBytes(is4, image4, file)
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                    imageFile4 =
                        RequestBody.create(MediaType.parse("multipart/form-data"), imageBytes)
                    body4 = MultipartBody.Part.createFormData("image4", Filenale, imageFile4)
                } else {
                    imageFile4 = RequestBody.create(MediaType.parse("multipart/form-data"), "")
                    body4 = MultipartBody.Part.createFormData("image4", "", imageFile4)
                }
                //IMAGE4 END

                //IMAGE5 START
                val image5 = PATH5
                val imageFile5: RequestBody
                val body5: MultipartBody.Part
                if (image5 != null) {
                    var imageBytes: ByteArray? = ByteArray(0)
                    val file = File(image5)
                    /* File file = new File(Fiximge,Fiximge);*/
                    val Filenale: String
                    Filenale = if (file.name.contains(".png")) {
                        file.name
                    } else {
                        file.name + ".png"
                    }
                    try {
                        imageBytes = getBytes(is5, image5, file)
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                    imageFile5 =
                        RequestBody.create(MediaType.parse("multipart/form-data"), imageBytes)
                    body5 = MultipartBody.Part.createFormData("image5", Filenale, imageFile5)
                } else {
                    imageFile5 = RequestBody.create(MediaType.parse("multipart/form-data"), "")
                    body5 = MultipartBody.Part.createFormData("image5", "", imageFile5)
                }
                //IMAGE5 END

//                Toast.makeText(DetailsViewActivity.this,"a:"+assetDetails.getAssetId()+
//                                "b:"+ batchDetail.getProjectId()+
//                                "c:"+ mode+
//                                "d:"+ "1"+
//                                "e:"+ text+
//                                "f:"+ batchDetail.getBatchId()+
//                                "g:"+ mUser.getProfileDetails().getUserId()+
//                                "h:"+rgId+
//                                "i:"+ remark.getText().toString()+
//                                "j:"+ use+
//                                "k:"+ notInuse+
//                                "l:"+ notF+
//                                "m:"+strPlantId+
//                                "n:"+ String.valueOf(selectedLocation)+
//                                "o:"+ String.valueOf(selectedSubLocation),
//                        Toast.LENGTH_LONG).show();
                if (imageArray!!.size != 0) {
                    NewSubmitAsset(
                        rbasset_id,
                        rbproject_id,
                        rbmode,
                        rbqty,
                        rbin_use,
                        rbbatch_id,
                        rbuser_id,
                        rbreason_id,
                        rbremark,
                        rbin_use_qty,
                        rbnot_in_use_qty,
                        rbnot_found_qty,
                        rbplant_id,
                        rblocation_id,
                        rbsub_location_id,
                        body1,
                        body2,
                        body3,
                        body4,
                        body5,
                        rbold_image1,
                        rbold_image2,
                        rbold_image3,
                        rbold_image4,
                        rbold_image5
                    )
                } else {
                    Toast.makeText(this, "Add at least one image.", Toast.LENGTH_LONG).show()
                }
                //                mViewModel.SubmitAsset(assetDetails.getAssetId(), batchDetail.getProjectId(), mode, "1", text, batchDetail.getBatchId(), mUser.getProfileDetails().getUserId(),
//                        rgId, remark.getText().toString(), use, notInuse, notF,strPlantId, String.valueOf(selectedLocation), String.valueOf(selectedSubLocation)).observe(this, new Observer<SendRespose>() {
//                    @Override
//                    public void onChanged(SendRespose sendRespose) {
//                        Toast.makeText(mDetailsViewActivity, "" + sendRespose.getRESPONSEMSG(), Toast.LENGTH_SHORT).show();
//                        finish();
//
//                    }
//
//                });

//                submitDetails(assetDetails.getAssetId(), batchDetail.getProjectId(), mode, "1", text, batchDetail.getBatchId(), mUser.getProfileDetails().getUserId(),
//                        rgId, remark.getText().toString(), use, notInuse, notF,strPlantId, String.valueOf(selectedLocation), String.valueOf(selectedSubLocation),"",
//                        "","","","",getBitmap(),getBitmap2(),getBitmap3(),getBitmap4(),getBitmap5());
            }
        } else {
            Toast.makeText(mDetailsViewActivity, "item not found ReScan", Toast.LENGTH_SHORT).show()
        }
    }

    fun showCodeEnterDialog(text: String?, isOverwrite: Boolean, reVerify: Boolean) {
        if (dialog != null && dialog!!.isShowing) {
            dialog!!.dismiss()
        }
        dialog = Dialog(this)
        dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog!!.setContentView(R.layout.lay_custome_enter_manualcode)
        val test = dialog!!.findViewById<TextView>(R.id.textmsg)
        test.text = text
        val dialogButton = dialog!!.findViewById<Button>(R.id.mSubmit)
        val Skip = dialog!!.findViewById<Button>(R.id.mSkip)
        if (!isOverwrite) {
            dialogButton.text = "Yes"
            Skip.text = "No"
        }
        Skip.setOnClickListener {
            dialog!!.cancel()
            mDetailsViewActivity!!.finish()
        }
        dialogButton.setOnClickListener {
            dialog!!.cancel()
            if (reVerify) {
//!                getDetails("1")
//!                getPlant(sessionManager!!.keY_new_client_id)
                //                    getLocation(sessionManager.getKEY_new_client_id(), String.valueOf(selectedPlantId));
                //                    getSubLocation(sessionManager.getKEY_new_client_id());
            } else {
//!               getDetails("0")
//!                getPlant(sessionManager!!.keY_new_client_id)
                //                    getLocation(sessionManager.getKEY_new_client_id(),String.valueOf(selectedPlantId));
                //                    getSubLocation(sessionManager.getKEY_new_client_id());
            }
        }
        if (!dialog!!.isShowing) {
            dialog!!.show()
        }
    }

    private fun showOverridePopup(text: String, reVerify: String) {
        if (dialog != null && dialog!!.isShowing()) {
            dialog!!.dismiss()
        }
        dialog = Dialog(this)
        dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog!!.setContentView(R.layout.lay_custome_enter_manualcode)
        val test = dialog!!.findViewById<TextView>(R.id.textmsg)
        test.text = text
        val dialogButton = dialog!!.findViewById<Button>(R.id.mSubmit)
        val Skip = dialog!!.findViewById<Button>(R.id.mSkip)
        Skip.setOnClickListener {
            dialog!!.dismiss()
            mDetailsViewActivity!!.finish()
        }
        dialogButton.setOnClickListener {
            dialog!!.dismiss()
//!            getDetails(reVerify)
//!            getPlant(sessionManager!!.keY_new_client_id)
        }
        if (!dialog!!.isShowing()) {
            dialog!!.show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == take_a_photo1) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                PATH = destination!!.absolutePath.toString()
                try {
                    //is1=getApplicationContext().getAssets().open(PATH);
                    is1 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: IOException) {
                    e.printStackTrace()
                }
                imageArray!!.add(PATH!!)
                binding.layDetailFragment.imgasset1.setImageBitmap(bitmap)
                binding.layDetailFragment.llAddImgAsset1.setVisibility(View.GONE)
                binding.layDetailFragment.llAvailableImgAsset1.setVisibility(View.VISIBLE)
            } else if (requestCode == edit_take_a_photo1) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                val storeFilename = "photo_$partFilename"
                val mBitmap = getImageFileFromSDCard(storeFilename)
                PATH = destination!!.absolutePath
                try {
                    is1 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
                //imageArray.add(PATH);
                binding.layDetailFragment.imgasset1.setImageBitmap(bitmap)
            } else if (requestCode == take_a_photo2) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                val storeFilename = "photo_$partFilename"
                val mBitmap = getImageFileFromSDCard(storeFilename)
                PATH2 = destination!!.absolutePath
                try {
                    is2 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
                imageArray!!.add(PATH2!!)
                binding.layDetailFragment.imgasset2.setImageBitmap(bitmap)
                binding.layDetailFragment.llAddImgAsset2.setVisibility(View.GONE)
                binding.layDetailFragment.llAvailableImgAsset2.setVisibility(View.VISIBLE)
            } else if (requestCode == edit_take_a_photo2) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                val storeFilename = "photo_$partFilename"
                val mBitmap = getImageFileFromSDCard(storeFilename)
                PATH2 = destination!!.absolutePath
                try {
                    is2 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
                //imageArray.add(PATH2);
                binding.layDetailFragment.imgasset2.setImageBitmap(bitmap)
            } else if (requestCode == take_a_photo3) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                Bitmap.createScaledBitmap(bitmap!!, 50, 50, true)
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                val storeFilename = "photo_$partFilename"
                val mBitmap = getImageFileFromSDCard(storeFilename)
                PATH3 = destination!!.absolutePath
                try {
                    is3 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
                imageArray!!.add(PATH3!!)
                binding.layDetailFragment.imgasset3.setImageBitmap(bitmap)
                binding.layDetailFragment.llAddImgAsset3.setVisibility(View.GONE)
                binding.layDetailFragment.llAvailableImgAsset3.setVisibility(View.VISIBLE)
            } else if (requestCode == edit_take_a_photo3) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                val storeFilename = "photo_$partFilename"
                val mBitmap = getImageFileFromSDCard(storeFilename)
                PATH3 = destination!!.absolutePath
                try {
                    is3 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }

                //imageArray.add(PATH3);
                boolimg3 = true
                strImageArray = "1"
                binding.layDetailFragment.imgasset3.setImageBitmap(bitmap)
            } else if (requestCode == take_a_photo4) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                val storeFilename = "photo_$partFilename"
                val mBitmap = getImageFileFromSDCard(storeFilename)
                PATH4 = destination!!.absolutePath
                try {
                    is4 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
                imageArray!!.add(PATH4!!)
                boolimg4 = true
                strImageArray = "1"
                binding.layDetailFragment.imgasset4.setImageBitmap(bitmap)
                binding.layDetailFragment.llAddImgAsset4.setVisibility(View.GONE)
                binding.layDetailFragment.llAvailableImgAsset4.setVisibility(View.VISIBLE)
            } else if (requestCode == edit_take_a_photo4) {
                bitmap = data!!.extras!!["data"] as Bitmap?
                val partFilename = currentDateFormat()
                storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                val storeFilename = "photo_$partFilename"
                val mBitmap = getImageFileFromSDCard(storeFilename)
                PATH4 = destination!!.absolutePath
                try {
                    is4 = contentResolver.openInputStream(Uri.fromFile(destination))
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }

                //imageArray.add(PATH4);
                boolimg4 = true
                strImageArray = "1"
                binding.layDetailFragment.imgasset4.setImageBitmap(bitmap)
            } else if (requestCode == take_a_photo5) {
                if (data != null) {
                    val extras = data.extras
                    if (extras != null) {
                        bitmap = extras["data"] as Bitmap?
                        if (bitmap != null) {
                            val partFilename = currentDateFormat()
                            storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                            val storeFilename = "photo_$partFilename"
                            val mBitmap = getImageFileFromSDCard(storeFilename)
                            PATH5 = destination!!.absolutePath
                            try {
                                is5 = contentResolver.openInputStream(Uri.fromFile(destination))
                            } catch (e: FileNotFoundException) {
                                e.printStackTrace()
                            }
                            imageArray!!.add(PATH5!!)
                            boolimg5 = true
                            strImageArray = "1"
                            binding.layDetailFragment.imgasset5.setImageBitmap(bitmap)
                            binding.layDetailFragment.llAddImgAsset5.setVisibility(View.GONE)
                            binding.layDetailFragment.llAvailableImgAsset5.setVisibility(View.VISIBLE)
                        }
                    }
                }
            } else if (requestCode == edit_take_a_photo5) {
                if (data != null) {
                    val extras = data.extras
                    if (extras != null) {
                        bitmap = extras["data"] as Bitmap?
                        if (bitmap != null) {
                            val partFilename = currentDateFormat()
                            storeCameraPhotoInSDCard(bitmap!!, partFilename!!)
                            val storeFilename = "photo_$partFilename"
                            val mBitmap = getImageFileFromSDCard(storeFilename)
                            PATH5 = destination!!.absolutePath
                            try {
                                is5 = contentResolver.openInputStream(Uri.fromFile(destination))
                            } catch (e: FileNotFoundException) {
                                e.printStackTrace()
                            }
                            // imageArray.add(PATH5);
                            boolimg5 = true
                            strImageArray = "1"
                            binding.layDetailFragment.imgasset5.setImageBitmap(bitmap)
                        }
                    }
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            REQUEST_CODE_ASK_PERMISSIONS -> if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                SubmmitAssetApi()
            } else {
                Toast.makeText(this@DetailsViewActivity, "Permission denied", Toast.LENGTH_SHORT)
                    .show()
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }


    }

    private fun storeCameraPhotoInSDCard(bitmap: Bitmap, currentDate: String) {
        val outputFile = File(
            Environment.getExternalStorageDirectory(),
            "photo_$currentDate"
        )
        try {
            val fileOutputStream = FileOutputStream(outputFile)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)
            fileOutputStream.flush()
            fileOutputStream.close()
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun NewSubmitAsset(
        asset_id: RequestBody,
        project_id: RequestBody,
        mode: RequestBody,
        qty: RequestBody,
        in_use: RequestBody,
        batch_id: RequestBody,
        user_id: RequestBody,
        reason_id: RequestBody,
        remark: RequestBody,
        in_use_qty: RequestBody,
        not_in_use_qty: RequestBody,
        not_found_qty: RequestBody,
        plant_id: RequestBody,
        location_id: RequestBody,
        sub_location_id: RequestBody,
        image1: MultipartBody.Part,
        image2: MultipartBody.Part,
        image3: MultipartBody.Part,
        image4: MultipartBody.Part,
        image5: MultipartBody.Part,
        old_image1: RequestBody,
        old_image2: RequestBody,
        old_image3: RequestBody,
        old_image4: RequestBody,
        old_image5: RequestBody
    ) {

        val serviceApi: ServiceApi = RetrofitClient.buildService(ServiceApi::class.java)
        val call: Call<SendRespose> = serviceApi.NewSubmitDetails(
            asset_id,
            project_id,
            mode,
            qty,
            in_use,
            batch_id,
            user_id,
            reason_id,
            remark,
            in_use_qty,
            not_in_use_qty,
            not_found_qty,
            plant_id,
            location_id,
            sub_location_id,
            image1,
            image2,
            image3,
            image4,
            image5,
            old_image1,
            old_image2,
            old_image3,
            old_image4,
            old_image5
        )
        call.enqueue(object : Callback<SendRespose> {
            override fun onResponse(call: Call<SendRespose>, response: Response<SendRespose>) {
                if (response.body()!!.responsestatus.equals("1")) {
                    Toast.makeText(
                        this@DetailsViewActivity,
                        response.body()!!.responsemsg,
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                } else {
                    Toast.makeText(
                        this@DetailsViewActivity,
                        response.body()!!.responsemsg,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<SendRespose>, t: Throwable) {
                //Toast.makeText(DetailsViewActivity.this,"Network Error"+t.getMessage(),Toast.LENGTH_LONG).show();
            }
        })
    }

    private fun deleteImage(asset_id: String, image_id: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.deleteImage(asset_id,image_id)
        call.enqueue(object : Callback<SendRespose> {
            override fun onResponse(call: Call<SendRespose>, response: Response<SendRespose>) {
                if (response.body()!!.responsestatus.equals("1")) {
                    Toast.makeText(
                        this@DetailsViewActivity,
                        response.body()!!.responsemsg,
                        Toast.LENGTH_LONG
                    ).show()
                    recreate()
                } else {
                    Toast.makeText(
                        this@DetailsViewActivity,
                        response.body()!!.responsemsg,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<SendRespose>, t: Throwable) {}
        })
    }

    private fun getImageFileFromSDCard(filename: String): Bitmap? {
        var bitmap: Bitmap? = null
        destination = File(Environment.getExternalStorageDirectory().toString() + "/" + filename)
        try {
            val fis = FileInputStream(destination)
            bitmap = BitmapFactory.decodeStream(fis)
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        }
        return bitmap
    }

    private fun currentDateFormat(): String? {
        val dateFormat = SimpleDateFormat("yyyyMMdd_HH_mm_ss")
        return dateFormat.format(Date())
    }

    @Throws(IOException::class)
    fun getBytes(`is`: InputStream?, str: String?, file: File): ByteArray? {
        var `is` = `is`
        var str = str
        var file = file
        val byteBuff = ByteArrayOutputStream()
        file = File(str)
        str = file.absolutePath
        `is` = contentResolver.openInputStream(Uri.fromFile(file))
        //is=getApplicationContext().getAssets().open(str);
        val finalIs = `is`
        runOnUiThread {
            val buffSize = 1024
            val buff = ByteArray(buffSize)
            var len = 0
            try {
                if (finalIs != null) {
                    while (finalIs.read(buff).also { len = it } != -1) {
                        byteBuff.write(buff, 0, len)
                    }
                }
            } catch (e: IOException) {
            }
        }
        //is=socket.getInputStream();
        return byteBuff.toByteArray()
    }
}