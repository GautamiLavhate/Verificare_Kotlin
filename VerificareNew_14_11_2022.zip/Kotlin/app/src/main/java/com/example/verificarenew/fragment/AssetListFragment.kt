package com.example.verificarenew.fragment

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ListView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.example.verificarenew.R
import com.example.verificarenew.activity.CurrentUser
import com.example.verificarenew.activity.DashboardActivity
import com.example.verificarenew.activity.DetailsViewActivity
import com.example.verificarenew.activity.ScannerActivity
import com.example.verificarenew.adapter.AssetListAdapter
import com.example.verificarenew.adapter.DialogListViewAdapter
import com.example.verificarenew.databinding.FragmentAssetListBinding
import com.example.verificarenew.model.AssetList
import com.example.verificarenew.model.BatchDetail
import com.example.verificarenew.model.User
import com.google.zxing.integration.android.IntentIntegrator


class AssetListFragment : Fragment() {
    private lateinit var binding: FragmentAssetListBinding
    private var mViewModel: AssetListViewModel? = null
    private val list: ArrayList<AssetList.AssetsDetail> = ArrayList<AssetList.AssetsDetail>()
    private val tempList: ArrayList<AssetList.AssetsDetail> = ArrayList<AssetList.AssetsDetail>()
    var assetListAdapter: AssetListAdapter? = null


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        mViewModel = ViewModelProviders.of(this)[AssetListViewModel::class.java]
        assetListAdapter = AssetListAdapter(list, object : AssetListAdapter.OnItemClickListener {


            override fun onItemClick(`object`: Any?) {
                val assetsDetail: AssetList.AssetsDetail = `object` as AssetList.AssetsDetail
                if (assetsDetail.getIsScan().equals("True")) {
                    IntentIntegrator(activity).setCaptureActivity(ScannerActivity::class.java)
                        .initiateScan()
                } else {
                    CallActivity(assetsDetail)
                }
            }
        })
        binding.rvListAsset.setAdapter(assetListAdapter)

        val getCurrentBatch = SetCurrentBatch.getInstance().currentBatch
        if (getCurrentBatch != null) {
            mViewModel!!.getAssetDetilas(getCurrentBatch.batchId, getCurrentBatch.projectId)!!
                .observe(
                    viewLifecycleOwner
                ) { assetList ->
                    if (!assetList.responsestatus.equals("0")) {
                        list.addAll(assetList.assetsDetails)
                        tempList.addAll(list)
                        assetListAdapter!!.notifyDataSetChanged()
                    }
                }
        }

        binding.ivBack.setOnClickListener {
            val dashboardActivity: DashboardActivity? = activity as DashboardActivity?
            dashboardActivity?.showToolBar()
            requireActivity().supportFragmentManager.popBackStack()
        }

        binding.flAssetSort.setOnClickListener {
            showSortingPopup()
        }

        binding.tvSubmitBatch.setOnClickListener {
            submitAllBatch()
        }

        binding.edtAssetSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                Log.d("gaurav", "afterTextChanged: $s")
                filter(s.toString())
            }
        })

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_asset_list, container, false)
        return binding.root
    }

    private fun submitAllBatch() {
        val batchDetail = SetCurrentBatch.getInstance().currentBatch
        val user: User = CurrentUser.getInstance().getUser()
        if (batchDetail != null) {
            mViewModel!!.submitBatchAll(
                batchDetail.batchId,
                batchDetail.projectId,
                user.getProfileDetails().getUserId()
            )!!
                .observe(
                    viewLifecycleOwner
                ) { submitBatch ->
                    Toast.makeText(
                        activity,
                        "" + submitBatch.responsemsg,
                        Toast.LENGTH_SHORT
                    ).show()
                }
        }
    }

    private fun CallActivity(assetsDetail: AssetList.AssetsDetail) {
        val getCurrentBatch: BatchDetail = SetCurrentBatch.getInstance().currentBatch
        mViewModel!!.getAssetDetails(
            getCurrentBatch.getBatchId(),
            getCurrentBatch.getProjectId(),
            "",
            "0",
            "0",
            "",
            assetsDetail.getAssetId()
        )
        val i = Intent(activity, DetailsViewActivity::class.java)
        i.putExtra("Code", assetsDetail.getAssetId())
        i.putExtra("isFromAsset", true)
        startActivity(i)
    }
    fun showSortingPopup(): Dialog? {
        val dialog = Dialog(requireActivity())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.lay_fillter_popup_view)
        val listView = dialog.findViewById<ListView>(R.id.mListView)
        val list: MutableList<String> = java.util.ArrayList()
        list.add("Completed quantity")
        list.add("Pending quantity")
        list.add("Auto Scan mode")
        list.add("Manual Scan mode")
        list.add("Reset")
        val adapter = DialogListViewAdapter(requireActivity(), list, object :
            DialogListViewAdapter.onClick {
            override fun onClickEvent(e: Any?, pos: Int) {
                dialog.dismiss()
                sort(pos)
            }
        })
        listView.adapter = adapter
        dialog.show()
        return dialog
    }

    private fun sort(pos: Int) {
        when (pos) {
            0 -> sortCompleted()
            1 -> sortPending()
            2 -> sortAuto()
            3 -> sortManual()
            4 -> reset()
        }
    }

    private fun reset() {
        list.clear()
        for (detail in tempList) {
            list.add(detail)
        }
        assetListAdapter!!.notifyDataSetChanged()
    }

    private fun sortCompleted() {
        list.clear()
        for (detail in tempList) {
            if (detail.assetStatus.equals("completed")) {
                list.add(detail)
            }
        }
        check()
        assetListAdapter!!.notifyDataSetChanged()
    }

    private fun sortPending() {
        list.clear()
        for (detail in tempList) {
            if (detail.assetStatus.equals("pending")) {
                list.add(detail)
            }
        }
        check()
        assetListAdapter!!.notifyDataSetChanged()
    }

    private fun sortManual() {
        list.clear()
        for (detail in tempList) {
            if (detail.isScan.equals("False")) {
                list.add(detail)
            }
        }
        check()
        assetListAdapter!!.notifyDataSetChanged()
    }
    private fun sortAuto() {
        list.clear()
        for (detail in tempList) {
            if (detail.isScan.equals("True")) {
                list.add(detail)
            }
        }
        check()
        assetListAdapter!!.notifyDataSetChanged()
    }
    private fun check() {
        if (list.size == 0) {
            Toast.makeText(activity, "No item found", Toast.LENGTH_SHORT).show()
        }
    }
    private fun filter(text: String) {

        //new array list that will hold the filtered data
        val filterdData: java.util.ArrayList<AssetList.AssetsDetail> = java.util.ArrayList<AssetList.AssetsDetail>()

        //looping through existing elements
        for (assetsDetail in list) {

            //if the existing elements contains the search input
            if (assetsDetail.assetNumber.toLowerCase().contains(text.toLowerCase())) {
                //adding the element to filtered list
                Log.d("gaurav", "filter: 1")
                filterdData.add(assetsDetail)
            } else {
                Log.d("gaurav", "filter: 0")
            }
        }
        assetListAdapter!!.filterList(filterdData)
    }


}