package com.example.verificarenew.fragment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.verificarenew.model.BatchDetails
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SetBatchViewModel:ViewModel() {
    private val mBatchDetailsMutableLiveData: MutableLiveData<BatchDetails>? =
        MutableLiveData<BatchDetails>()

    fun getBatchDetails(id: String): LiveData<BatchDetails>? {
        if (mBatchDetailsMutableLiveData != null) {
            loadBatchDeatils(id)
        }
        return mBatchDetailsMutableLiveData
    }

    private fun loadBatchDeatils(id: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getBatchdetails(id)
        call.enqueue(object : Callback<BatchDetails?> {
            override fun onResponse(call: Call<BatchDetails?>, response: Response<BatchDetails?>) {
                val batchDetails: BatchDetails? = response.body()
                if (batchDetails?.getRESPONSESTATUS().equals("1")) {

                }
                if (batchDetails != null) {
                    mBatchDetailsMutableLiveData!!.setValue(batchDetails)
                }
            }

            override fun onFailure(call: Call<BatchDetails?>, t: Throwable) {}
        })
    }
}