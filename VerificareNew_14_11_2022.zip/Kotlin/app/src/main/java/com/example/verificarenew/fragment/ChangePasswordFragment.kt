package com.example.verificarenew.fragment

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.example.verificarenew.R
import com.example.verificarenew.activity.CurrentUser
import com.example.verificarenew.activity.ProfileActivity
import com.example.verificarenew.databinding.FragmentChangePasswordBinding
import com.example.verificarenew.model.Profile
import com.example.verificarenew.model.User
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ChangePasswordFragment : Fragment() {
    private lateinit var binding: FragmentChangePasswordBinding
    private var profileActivity: ProfileActivity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_change_password, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        profileActivity = activity as ProfileActivity?
        val user: User = CurrentUser.getInstance().getUser()

        binding.edtConfirmPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                binding.tilConfirmPassword.setError("")
            }
        })

        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.changePassword(binding.edtCurrentPassword.text.toString().trim(),
            binding.edtNewPassword.text.toString().trim(),binding.edtConfirmPassword.text.toString().trim(),
            user.profileDetails.userId)
        call.enqueue(object : Callback<Profile?> {
            override fun onResponse(call: Call<Profile?>, response: Response<Profile?>) {
                if (response.isSuccessful && response.body() != null) {
                    if (response.body()!!.responsestatus.equals("1")) {
                        profileActivity!!.ExitApp()
                        Toast.makeText(activity, response.body()!!.responsemsg, Toast.LENGTH_LONG)
                            .show()
                    } else {
                        Toast.makeText(activity, response.body()!!.responsemsg, Toast.LENGTH_LONG)
                            .show()
                    }
                }
            }

            override fun onFailure(call: Call<Profile?>, t: Throwable) {
                Toast.makeText(activity, "Error Occurred...", Toast.LENGTH_LONG).show()
            }
        })

    }

    private fun isValid(): Boolean {
        if (binding.edtCurrentPassword.getText().toString()
                .isEmpty() || binding.edtCurrentPassword.getText().toString() == ""
        ) {
            binding.tilCurrentPassword.setError("Can't be empty")
            return false
        } else if (binding.edtNewPassword.getText().toString()
                .isEmpty() || binding.edtNewPassword.getText().toString() == ""
        ) {
            binding.tilNewPassword.setError("Can't be empty")
            return false
        } else if (binding.edtConfirmPassword.getText().toString()
                .isEmpty() || binding.edtConfirmPassword.getText().toString() == ""
        ) {
            binding.tilConfirmPassword.setError("Can't be empty")
            return false
        } else if (binding.edtNewPassword.getText().toString() != binding.edtConfirmPassword.getText()
                .toString()
        ) {
            binding.tilConfirmPassword.setError("New password & Confirm password not match.")
            return false
        }
        return true
    }

    override fun onResume() {
        super.onResume()
        profileActivity!!.setTitle("Change Password")
    }

    private fun changePassword() {}
}