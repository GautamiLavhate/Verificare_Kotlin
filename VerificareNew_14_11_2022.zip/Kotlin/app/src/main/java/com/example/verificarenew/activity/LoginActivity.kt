package com.example.verificarenew.activity

import android.content.Intent
import android.hardware.usb.UsbDevice.getDeviceName
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityLoginBinding
import com.example.verificarenew.model.User
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import com.example.verificarenew.network.SessionManager
import com.example.verificarenew.util.AlertDialog
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {
    private lateinit var binding:ActivityLoginBinding
    var sessionManager: SessionManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_login)
        sessionManager = SessionManager(this@LoginActivity)
        supportActionBar!!.hide()
    }
    fun login(view: View) {
        if (!validate())
        {
            return
        }

        var android_id = Settings.Secure.getString(this@LoginActivity.contentResolver, Settings.Secure.ANDROID_ID)

        var device_name: String = getDeviceName().toString()
        //Toast.makeText(this,binding.edtUsername.getText().toString()+","+binding.edtPassword.getText().toString()+","+android_id+","+device_name,Toast.LENGTH_LONG).show()
        signIn(binding.edtUsername.getText().toString(), binding.edtPassword.getText().toString(), android_id, device_name) //static device id "12345678999999"
    }

    /** Returns the consumer friendly device name  */
    fun getDeviceName(): String? {
        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL
        return if (model.startsWith(manufacturer)) {
            capitalize(model)
        } else capitalize(manufacturer) + " " + model
    }

    private fun capitalize(str: String): String? {
        if (TextUtils.isEmpty(str)) {
            return str
        }
        val arr = str.toCharArray()
        var capitalizeNext = true
        var phrase: String? = ""
        for (c in arr) {
            if (capitalizeNext && Character.isLetter(c)) {
                phrase += Character.toUpperCase(c)
                capitalizeNext = false
                continue
            } else if (Character.isWhitespace(c)) {
                capitalizeNext = true
            }
            phrase += c
        }
        return phrase
    }

    fun validate(): Boolean {
        var valid = true
        val username: String = binding.edtUsername.getText().toString().trim { it <= ' ' }
        val password: String = binding.edtPassword.getText().toString().trim { it <= ' ' }
        if (username.isEmpty()) {
            binding.llWarning.setVisibility(View.VISIBLE)
            valid = false
        }
        if (password.isEmpty() || password.length < 6) {
            binding.llWarning.setVisibility(View.VISIBLE)
            valid = false
        }
        return valid
    }

    fun signIn(username: String, Pass: String, device_id: String, device_name: String) {

        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.UserLogin(username,Pass,device_id,device_name)
        call.enqueue(object : Callback<User?> {
            override fun onResponse(call: Call<User?>, response: Response<User?>) {
                val user = response.body()
                //Toast.makeText(this@LoginActivity,user?.responsestatus,Toast.LENGTH_LONG).show()
                if (user != null && user.responsestatus.equals("1")) {
                    onLoginSuccess(user)
                    Toast.makeText(this@LoginActivity,user.profileDetails.clientId,Toast.LENGTH_LONG).show()
                    sessionManager?.createLogin(
                        user.profileDetails.userName,
                        user.profileDetails.email,
                        user.profileDetails.name,
                        user.profileDetails.photo,
                        user.profileDetails.clientId,
                        user.profileDetails.userId,
                        user.profileDetails.lastLogin,
                        user.profileDetails.userType
                    )
                } else {
                    //Toast.makeText(LoginActivity.this, "" + user.getRESPONSEMSG(), Toast.LENGTH_SHORT).show();
                    LoginUnSuccess(user!!.responsemsg)
                }
            }

            override fun onFailure(call: Call<User?>, t: Throwable) {
                onLoginFailure()
            }
        })
    }

    fun onLoginSuccess(user: User?) {
        val mAlertDialog = AlertDialog(this)
        mAlertDialog.showDialog(
            "Logged in Successfully",
            "After active hours your account will auto logout"
        )
        mAlertDialog.setListener(object : AlertDialog.IAlertListener {
            override fun onClick(o: Any?) {
                CallActivity(user!!)
                CurrentUser.getInstance().setCurrentUser(user)
            }
        })
    }

    fun LoginUnSuccess(message: String?) {
        val mAlertDialog = AlertDialog(this)
        mAlertDialog.showDialog("Login Unsuccessful!", message)
        mAlertDialog.setListener(object : AlertDialog.IAlertListener {
            override fun onClick(o: Any?) {}
        })
    }

    private fun CallActivity(user: User) {
        val intent = Intent(this, DashboardActivity::class.java)
        intent.putExtra("user", user)
        startActivity(intent)
        finish()
    }

    fun onLoginFailure() {
        Toast.makeText(baseContext, "Login failed", Toast.LENGTH_LONG).show()
    }
    fun launchForgotPasswordActivity(view: View) {
        val intent = Intent(this, ForgotPasswordActivity::class.java)
        startActivity(intent)
    }
    override fun onDestroy() {
        super.onDestroy()
    }


}