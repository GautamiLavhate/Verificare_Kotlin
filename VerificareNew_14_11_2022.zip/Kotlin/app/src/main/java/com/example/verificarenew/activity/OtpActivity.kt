package com.example.verificarenew.activity

import android.content.Intent
import android.graphics.Paint
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityOtpBinding

class OtpActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOtpBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_otp)
        val bundle = intent.extras
        var email: String? = null
        if (bundle != null) {
            email = bundle.getString("Email")
        }

        binding.tvMessage2.setPaintFlags(binding.tvMessage2.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
        binding.tvMessage2.setText(email)

        if (supportActionBar != null) {
            supportActionBar!!.title = ""
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            supportActionBar!!.setDisplayShowHomeEnabled(true)
        }
    }

    fun resendCode(view: View) {
        Toast.makeText(this, "Code sent", Toast.LENGTH_SHORT).show()
    }
    fun launchSetPasswordActivity(view: View) {
        val intent = Intent(this, SetPasswordActivity::class.java)
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
        }
        return super.onOptionsItemSelected(item)

    }
}