package com.example.verificarenew.network

import com.example.verificarenew.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ServiceApi {
    @FormUrlEncoded
    @POST("app_login.php")
    fun UserLogin(
        @Field("username") username: String,
        @Field("password") password: String,
        @Field("device_id") device_id: String,
        @Field("device_name") device_name: String
    ): Call<User>

    @GET("app_get_aboutus.php")
    fun getAboutUs(): Call<AboutUs>

    @FormUrlEncoded
    @POST("app_get_profile.php")
    fun getProfile(@Field("user_id") user_id: String): Call<Profile>

    @FormUrlEncoded
    @POST("app_logout.php")
    fun logout(@Field("user_id") user_id: String,
                @Field("device_id") device_id: String): Call<User>

    @FormUrlEncoded
    @POST("app_change_password.php")
    fun changePassword(
        @Field("old_password") old_password: String?,
        @Field("new_password") new_password: String?,
        @Field("conf_password") conf_password: String?,
        @Field("user_id") user_id: String?
    ): Call<Profile>

    @FormUrlEncoded
    @POST("app_get_location.php")
    fun getLocations(
        @Field("client_id") client_id: String?
    ): Call<Location>

    @FormUrlEncoded
    @POST("app_get_location.php")
    fun getLocationAsPerPlant(
        @Field("client_id") client_id: String?,
        @Field("plant_id") plant_id: String?
    ): Call<Location>

    @FormUrlEncoded
    @POST("app_get_sub_location.php")
    fun getSubLocation(
        @Field("client_id") client_id: String?
    ): Call<SubLocation>

    @FormUrlEncoded
    @POST("app_get_sub_location.php")
    fun getSubLocationAsPerLocation(
        @Field("client_id") client_id: String?,
        @Field("location_id") location_id: String?
    ): Call<SubLocation>

    @FormUrlEncoded
    @POST("app_get_batch.php")
    fun getBatchdetails(
        @Field("user_id") user_id: String?
    ): Call<BatchDetails>

    @FormUrlEncoded
    @POST("app_get_assets.php")
    fun getAssetList(
        @Field("batch_id") batchId: String?,
        @Field("project_id") ProjectId: String?
    ): Call<AssetList>

    @FormUrlEncoded
    @POST("app_get_asset_details.php")
    fun getAssetDetail(
        @Field("batch_id") batch_id: String?,
        @Field("project_id") project_id: String?,
        @Field("unique_id") unique_id: String?,
        @Field("other_batch") other_batch: String?,
        @Field("re_verify") re_verify: String?,
        @Field("reason") reason: String?,
        @Field("asset_id") asset_id: String?
    ): Call<DetailScan>

    @FormUrlEncoded
    @POST("app_submit_batch.php")
    fun submitBatch(
        @Field("asset_id") batchid: String?,
        @Field("project_id") project_id: String?, @Field("user_id") user_id: String?
    ): Call<SubmitBatch>


    @FormUrlEncoded
    @POST("app_get_dashboard_details.php")
    fun getDashBoard(
        @Field("batch_id") batchId: String?,
        @Field("project_id") ProjectId: String?
    ): Call<Dashboard>

    @FormUrlEncoded
    @POST("app_verify_asset.php")
    fun getScanResult(
        @Field("project_id") ProjectId: String?,
        @Field("batch_id") batchId: String?,
        @Field("qr_code") qr_code: String?,
        @Field("other_batch") other_batch: String?,
        @Field("re_verify") re_verify: String?,
        @Field("scan_by") scantype: String?
    ): Call<DetailScan>

    @FormUrlEncoded
    @POST("app_verify_asset_rfid.php")
    fun getScanResultRFID(
        @Field("project_id") ProjectId: String?,
        @Field("batch_id") batchId: String?,
        @Field("code") qr_code: String?,
        @Field("other_batch") other_batch: String?,
        @Field("re_verify") re_verify: String?,
        @Field("scan_by") scantype: String?
    ): Call<DetailScan>

    @GET("app_get_reason.php")
    fun getAllResons(): Call<Reson>

    @FormUrlEncoded
    @POST("app_submit_details.php")
    fun SubmmitAssetOld(
        @Field("asset_id") asset_id: String?,
        @Field("project_id") project_id: String?,
        @Field("mode") mode: String?,
        @Field("qty") qty: String?,
        @Field("in_use") in_use: String?,
        @Field("batch_id") batch_id: String?,
        @Field("user_id") user_id: String?,
        @Field("reason_id") reason_id: String?,
        @Field("remark") remark: String?,
        @Field("in_use_qty") in_use_qty: String?,
        @Field("not_in_use_qty") not_in_use_qty: String?,
        @Field("not_found_qty") not_found_qty: String?,
        @Field("plant_id") plant_id: String?,
        @Field("location_id") location_id: String?,
        @Field("sub_location_id") sub_location_id: String?
    ): Call<SendRespose>

    @POST("app_asset_info.php")
    @FormUrlEncoded
    fun getDetails(
        @Field("qr_code") qr_code: String?,
        @Field("code") code: String?
    ): Call<Details>

    @FormUrlEncoded
    @POST("app_delete_asset_image.php")
    fun deleteImage(
        @Field("asset_id") asset_id: String?,
        @Field("field") field: String?
    ): Call<SendRespose>

    @Multipart
    @POST("app_submit_details.php")
    fun NewSubmitDetails(
        @Part("asset_id") asset_id: RequestBody?,
        @Part("project_id") project_id: RequestBody?,
        @Part("mode") mode: RequestBody?,
        @Part("qty") qty: RequestBody?,
        @Part("in_use") in_use: RequestBody?,
        @Part("batch_id") batch_id: RequestBody?,
        @Part("user_id") user_id: RequestBody?,
        @Part("reason_id") reason_id: RequestBody?,
        @Part("remark") remark: RequestBody?,
        @Part("in_use_qty") in_use_qty: RequestBody?,
        @Part("not_in_use_qty") not_in_use_qty: RequestBody?,
        @Part("not_found_qty") not_found_qty: RequestBody?,
        @Part("plant_id") plant_id: RequestBody?,
        @Part("location_id") location_id: RequestBody?,
        @Part("sub_location_id") sub_location_id: RequestBody?,
        @Part image1: MultipartBody.Part?,
        @Part image2: MultipartBody.Part?,
        @Part image3: MultipartBody.Part?,
        @Part image4: MultipartBody.Part?,
        @Part image5: MultipartBody.Part?,
        @Part("old_image1") old_image1: RequestBody?,
        @Part("old_image2") old_image2: RequestBody?,
        @Part("old_image3") old_image3: RequestBody?,
        @Part("old_image4") old_image4: RequestBody?,
        @Part("old_image5") old_image5: RequestBody?
    ): Call<SendRespose>
}