package com.example.verificarenew.fragment

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.verificarenew.R
import com.example.verificarenew.activity.CurrentUser
import com.example.verificarenew.activity.DashboardActivity
import com.example.verificarenew.activity.ScannerActivity
import com.example.verificarenew.adapter.DialogListViewAdapter
import com.example.verificarenew.adapter.SetBatchListAdapter
import com.example.verificarenew.databinding.FragmentSetBatchBinding
import com.example.verificarenew.fragmnetlistener.IFragmentListener
import com.example.verificarenew.model.BatchDetail
import com.example.verificarenew.model.BatchDetails
import com.example.verificarenew.model.User
import com.example.verificarenew.network.SessionManager
import com.google.zxing.integration.android.IntentIntegrator


class SetBatchFragment : Fragment() , IFragmentListener {
    private lateinit var binding:FragmentSetBatchBinding
    private var mViewModel: SetBatchViewModel? = null
    private var mUser: User? = null
    private var mIFragmentListener: IFragmentListener? = null
    private var setBatchListAdapter: SetBatchListAdapter? = null
    private val batchList: ArrayList<BatchDetail> = ArrayList<BatchDetail>()
    private val batchTempList: ArrayList<BatchDetail> = ArrayList<BatchDetail>()
    private val edtBatchSearch: EditText? = null
    val TARGET_FRAGMENT_REQUEST_CODE = 1
    val EXTRA_GREETING_MESSAGE = "message"

    private var isVisiblee = false
    var sessionManager: SessionManager? = null



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_set_batch, container, false)
        sessionManager = SessionManager(context)
//        mIFragmentListener = getActivity() as IFragmentListener?
        binding.edtBatchSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                Log.d("gaurav", "afterTextChanged: $s")
                filter(s.toString())
            }
        })
        return binding.root
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) {
            return
        }
        if (requestCode == TARGET_FRAGMENT_REQUEST_CODE) {
            val rfid = data!!.getStringExtra(EXTRA_GREETING_MESSAGE)
            edtBatchSearch!!.setText(rfid)
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mViewModel = ViewModelProviders.of(this)[SetBatchViewModel::class.java]
        mUser = CurrentUser.getInstance().getUser()

        binding.icInfo.setOnClickListener {
            if (isVisiblee) {
                binding.icQR.setVisibility(View.GONE)
                binding.icRFID.setVisibility(View.GONE)
            } else {
                binding.icQR.setVisibility(View.VISIBLE)
                binding.icRFID.setVisibility(View.VISIBLE)
            }
            isVisiblee = !isVisiblee
        }

        binding.icQR.setOnClickListener {
            SetCurrentBatch.setIsDetailsOnly(true)
            SetCurrentBatch.setType("qr")
            IntentIntegrator(activity).setCaptureActivity(ScannerActivity::class.java)
                .initiateScan()
        }

        binding.icRFID.setOnClickListener {
            SetCurrentBatch.setType("rfid")
            SetCurrentBatch.setIsDetailsOnly(true)
            val dialogFragment: RFIDDialogFragment = RFIDDialogFragment()
            dialogFragment.show(requireActivity().supportFragmentManager, "Test")
        }

        setBatchListAdapter = SetBatchListAdapter(requireContext(),batchList, object : SetBatchListAdapter.OnClickItem {
            override fun onClick(item: Any?) {
                val activity: DashboardActivity? = activity as DashboardActivity?
                mIFragmentListener = getActivity() as IFragmentListener?     
                activity?.showToolBar()
                mIFragmentListener!!.sendBatchDetails((item as BatchDetail?)!!)
                SetCurrentBatch.getInstance().setCurrentBatchDetails(item)
                for (i in batchList.indices) {
                }
                requireActivity().supportFragmentManager.popBackStack()
            }
        })

        binding.rvListBatch.setAdapter(setBatchListAdapter)

        if (mUser != null && mUser!!.profileDetails != null) {
            mViewModel!!.getBatchDetails(mUser!!.profileDetails.userId)!!.observe(viewLifecycleOwner,
                Observer<BatchDetails> { batchDetails ->
                    if (batchDetails.getRESPONSESTATUS().equals("0")) {
                        showPopup(batchDetails.getRESPONSEMSG(), false)
                        return@Observer
                    }
                    val batchDetail: List<BatchDetail> = batchDetails.getBatchDetails()
                    if (batchDetail != null && batchDetail.size > 0) {
                        batchList.addAll(batchDetails.getBatchDetails())
                        batchTempList.addAll(batchList)
                        setBatchListAdapter!!.notifyDataSetChanged()
                    }
                })
        }

        binding.ivBack.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
            val dashboardActivity = activity as DashboardActivity?
            dashboardActivity!!.showToolBar()
        }

        binding.flBatchSort.setOnClickListener {
            showSortingPopup()
        }
    }

    fun showPopup(text: String?, isShowTwoButton: Boolean): Dialog? {
        val dialog = Dialog(requireActivity())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.lay_exit_dialog)
        val test = dialog.findViewById<TextView>(R.id.textmsg)
        if (!isShowTwoButton) {
            test.text = text
        }
        val btnYes = dialog.findViewById<Button>(R.id.btnYes)
        val btnNo = dialog.findViewById<Button>(R.id.btnNo)
        if (isShowTwoButton) {
            btnNo.visibility = View.VISIBLE
            btnNo.text = "No"
            btnYes.visibility = View.VISIBLE
            btnYes.text = "Yes"
        } else {
            btnNo.visibility = View.GONE
            btnYes.visibility = View.VISIBLE
            btnYes.text = "Ok"
        }
        btnNo.setOnClickListener { dialog.dismiss() }
        btnYes.setOnClickListener { dialog.dismiss() }
        dialog.show()
        return dialog
    }

    fun showSortingPopup(): Dialog? {
        val dialog = Dialog(requireActivity())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.lay_fillter_popup_view)
        val listView = dialog.findViewById<ListView>(R.id.mListView)
        val list: MutableList<String> = java.util.ArrayList()
        list.add("Completed quantity")
        list.add("Pending quantity")
        list.add("Completed and pending")
        list.add("Reset")
        val adapter = DialogListViewAdapter(requireActivity(), list, object :
            DialogListViewAdapter.onClick {
            override fun onClickEvent(e: Any?, pos: Int) {
                dialog.dismiss()
                sort(pos)
            }
        })
        listView.adapter = adapter
        dialog.show()
        return dialog
    }

    private fun sort(pos: Int) {
        when (pos) {
            0 -> sortCompleted()
            1 -> sortPending()
            2 -> sortCompletedPending()
            3 -> reset()
        }
    }

    private fun reset() {
        batchList.clear()
        for (detail in batchTempList) {
            batchList.add(detail)
        }
        setBatchListAdapter!!.notifyDataSetChanged()
    }

    private fun sortCompleted() {
        batchList.clear()
        for (detail in batchTempList) {
            if (detail.batchId.equals("completed")) {
                batchList.add(detail)
            }
        }
        check()
        setBatchListAdapter!!.notifyDataSetChanged()
    }

    private fun sortPending() {
        batchList.clear()
        for (detail in batchTempList) {
            if (detail.batchStatus.equals("in_progress")) {
                batchList.add(detail)
            }
        }
        check()
        setBatchListAdapter!!.notifyDataSetChanged()
    }

    private fun sortCompletedPending() {
        batchList.clear()
        for (detail in batchTempList) {
//            if (detail.getIsScan().equals("False")) {
//                batchList.add(detail);
//            }
        }
        check()
        setBatchListAdapter!!.notifyDataSetChanged()
    }
    private fun check() {
        if (batchList.size == 0) {
            Toast.makeText(activity, "No item found", Toast.LENGTH_SHORT).show()
        }
    }
    private fun filter(text: String) {
        val filterdData = java.util.ArrayList<BatchDetail>()
        for (batchDetail in batchList) {
            if (batchDetail.batchName.toLowerCase().contains(text.toLowerCase())) {
                filterdData.add(batchDetail)
            }
        }
        setBatchListAdapter!!.filterList(filterdData)
    }

    override fun sendBatchDetails(batchDetail: BatchDetail) {
        Toast.makeText(context,"1",Toast.LENGTH_LONG).show()
    }

}