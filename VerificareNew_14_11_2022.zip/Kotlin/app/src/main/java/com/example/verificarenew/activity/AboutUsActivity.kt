package com.example.verificarenew.activity

import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View.OnLongClickListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityAboutUsBinding
import com.example.verificarenew.model.AboutUs
import com.example.verificarenew.model.AboutusDetails
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import com.example.verificarenew.util.Utility
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AboutUsActivity : AppCompatActivity() {
    private lateinit var binding:ActivityAboutUsBinding
    private val TAG = "AboutUsActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_about_us)
        binding.descWebview.setVerticalScrollBarEnabled(false)
        binding.descWebview.setOnLongClickListener(OnLongClickListener { true })
        binding.descWebview.setLongClickable(false)
        binding.descWebview.setHapticFeedbackEnabled(false)
        supportActionBar!!.title = resources.getString(R.string.about_us)
        if (supportActionBar != null) {
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            supportActionBar!!.setDisplayShowHomeEnabled(true)
        }
        getData()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun getData(){
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getAboutUs()
        call.enqueue(object : Callback<AboutUs?> {
            override fun onResponse(call: Call<AboutUs?>, response: Response<AboutUs?>) {
                val aboutUs: AboutUs? = response.body()
                if (aboutUs != null) {
                    val aboutUsDetails: AboutusDetails = aboutUs.getAboutusDetails()
                    if (aboutUsDetails != null) {
                        Log.d(TAG, "onResponse: " + aboutUsDetails.getCompanyName())
                        Glide.with(applicationContext).load(aboutUsDetails.getLogo())
                            .into(binding.ivAboutUs)
                        val htmlData: String = Utility.getJustifyString(aboutUsDetails.getAbout())
                        binding.descWebview.loadData(htmlData, "text/html; charset=utf-8", "utf-8")
                        binding.tvAboutUsContent.setText(aboutUsDetails.getAbout())
                        binding.tvCompany.setText(aboutUsDetails.getCompanyName())
                        binding.tvTelephone.setText(aboutUsDetails.getCompanyPhone())
                        binding.tvEmail.setText(aboutUsDetails.getCompanyEmail())
                        binding.tvWebsite.setText(aboutUsDetails.getCompanyDomain())
                        binding.tvMobile.setText(aboutUsDetails.getCompanyMobile())
                    }
                }
            }

            override fun onFailure(call: Call<AboutUs?>, t: Throwable) {
                Toast.makeText(this@AboutUsActivity, "Failure", Toast.LENGTH_SHORT).show()
                call.cancel()
            }
        })
    }
}