package com.example.verificarenew.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.example.verificarenew.R;

public class LoginActivityNew extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_new);
    }

    public void login(View view) {
    }

    public void launchForgotPasswordActivity(View view) {
    }
}