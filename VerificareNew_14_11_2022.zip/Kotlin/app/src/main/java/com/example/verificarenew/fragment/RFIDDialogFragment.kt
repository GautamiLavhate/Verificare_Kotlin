package com.example.verificarenew.fragment

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.DialogFragment
import com.example.verificarenew.R
import com.example.verificarenew.activity.AssetDetailActivity
import com.example.verificarenew.activity.DashboardActivity
import com.example.verificarenew.activity.DetailsViewActivity
import com.example.verificarenew.databinding.FragmentRFIDDialogBinding
import com.example.verificarenew.util.SystemSound

class RFIDDialogFragment : DialogFragment() {
    private lateinit var binding: FragmentRFIDDialogBinding
    private var sound: SystemSound? = null
    private var dashboardActivity: DashboardActivity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun getInstance(): RFIDDialogFragment? {
        return RFIDDialogFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_r_f_i_d_dialog, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dashboardActivity = activity as DashboardActivity?
        sound = SystemSound()

        if (SetCurrentBatch.getIsDetailsOnly()) {
            binding.icManualMode.setVisibility(View.GONE)
        } else {
            binding.icManualMode.setVisibility(View.VISIBLE)
        }

        binding.icManualMode.setOnClickListener(View.OnClickListener { showDialog() })
        binding.text.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s.length > 9) {
                    if (dashboardActivity!!.getPreference("sound")) {
                        sound!!.successTune()
                    }
                    val data: String = binding.text.getText().toString()
                    sendResult(data)
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })
    }

    private fun showDialog() {
        val dialog = Dialog(requireActivity())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.lay_custome_dialog)
        val dailogText = dialog.findViewById<EditText>(R.id.edEnterCode)
        val spinner = dialog.findViewById<Spinner>(R.id.spReasonRFID)
        val spinnerGone = dialog.findViewById<Spinner>(R.id.sRegion)
        spinnerGone.visibility = View.GONE
        spinner.visibility = View.VISIBLE
        val dialogButton = dialog.findViewById<Button>(R.id.btSubmit)
        dialogButton.setOnClickListener {
            val re = spinner.selectedItem as String
            val text = dailogText.text.toString()
            if (!text.isEmpty() && spinner.selectedItemPosition != 0) {
                dialog.dismiss()
                if (SetCurrentBatch.getIsDetailsOnly()) {
                    val intent = Intent(activity, AssetDetailActivity::class.java)
                    intent.putExtra("Code", text)
                    startActivity(intent)
                } else {
                    CallActivity(text, re)
                }
            } else {
                Toast.makeText(
                    context,
                    "Please select reason & add code to proceed...",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        dialog.show()
    }

    private fun sendResult(s: String) {
        if (SetCurrentBatch.getIsDetailsOnly()) {
            val intent = Intent(activity, AssetDetailActivity::class.java)
            intent.putExtra("Code", s)
            startActivity(intent)
        } else {
            CallActivity(s, "")
        }
        dismiss()
    }
    private fun CallActivity(code: String, re: String) {
        if (!code.isEmpty()) {
            if (re.isEmpty() && re.equals("", ignoreCase = true)) {
                val i = Intent(activity, DetailsViewActivity::class.java)
                i.putExtra("Code", code)
                i.putExtra("Type", "rfid")
                i.putExtra("isManual", false)
                i.putExtra("r", re)
                startActivity(i)
            } else {
                val i = Intent(activity, DetailsViewActivity::class.java)
                i.putExtra("Code", code)
                i.putExtra("Type", "rfid")
                i.putExtra("isManual", true)
                i.putExtra("r", re)
                startActivity(i)
            }
        } else {
            Toast.makeText(activity, "Scan RFID code again...", Toast.LENGTH_SHORT).show()
        }
    }
}