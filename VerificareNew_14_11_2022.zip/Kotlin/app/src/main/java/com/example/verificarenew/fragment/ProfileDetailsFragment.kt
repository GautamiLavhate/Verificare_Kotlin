package com.example.verificarenew.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.verificarenew.R
import com.example.verificarenew.activity.CurrentUser
import com.example.verificarenew.activity.ProfileActivity
import com.example.verificarenew.databinding.FragmentProfileDetailsBinding
import com.example.verificarenew.model.Profile
import com.example.verificarenew.model.User


class ProfileDetailsFragment : Fragment() {

    private lateinit var binding:FragmentProfileDetailsBinding
    private var profileActivity: ProfileActivity? = null
    private var mViewModel: ProfileDetailsViewModel? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_profile_details, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        profileActivity = activity as ProfileActivity?
        mViewModel = ViewModelProviders.of(this)[ProfileDetailsViewModel::class.java]
        val user: User = CurrentUser.getInstance().getUser()

        binding.lay.tvProfileChangePass.setOnClickListener(View.OnClickListener {
            val fragmentManager = requireActivity().supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.container_profile, ChangePasswordFragment())
            fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commit()
        })
        if (user != null) {
            mViewModel!!.getBatchDetails(user.profileDetails.userId)!!.observe(
                viewLifecycleOwner
            ) { profile ->
                val profileDetails: Profile.ProfileDetails = profile.profileDetails
                if (profileDetails != null) {
                    loadPhoto(profileDetails.getPhoto())
                    binding.lay.tvProfileName.setText(profileDetails.getName())
                    binding.lay.tvProfileEmail.setText(profileDetails.getEmail())
                    if (profileDetails.getMobile() != null) {
                        binding.lay.tvProfileMobile.setText(java.lang.String.format("%s", profileDetails.getMobile()))
                    }
                    binding.lay.tvProfileAadhar.setText(profileDetails.getAadharNo())
                    binding.lay.tvProfileEmployeeType.setText(profileDetails.getUserType())
                    binding.lay.tvProfileCompanyName.setText("")
                }
            }
        }

        binding.lay.mbtnLogout.setOnClickListener(View.OnClickListener {
            profileActivity!!.showExitPOP(
                "Do you want to Logout?",
                true
            )
        })
    }

    private fun loadPhoto(url: String) {
        val options = RequestOptions()
            .placeholder(R.drawable.ic_profile)
            .timeout(3000)
            .override(80, 80)
            .error(R.drawable.ic_profile)
        Glide.with(this).asBitmap().load(url).apply(options).into(binding.lay.ivProfilePicture)
    }

    override fun onResume() {
        super.onResume()
        profileActivity!!.title = "Profile"
    }
}