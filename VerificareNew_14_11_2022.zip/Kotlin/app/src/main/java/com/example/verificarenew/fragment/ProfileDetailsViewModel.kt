package com.example.verificarenew.fragment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.verificarenew.model.Profile
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileDetailsViewModel:ViewModel() {
    private val mProfileDetails: MutableLiveData<Profile>? = MutableLiveData<Profile>()

    fun getBatchDetails(id: String): LiveData<Profile>? {
        if (mProfileDetails != null) {
            loadProfileDetails(id)
        }
        return mProfileDetails
    }

    private fun loadProfileDetails(id: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getProfile(id)

        call.enqueue(object : Callback<Profile?> {
            override fun onResponse(call: Call<Profile?>, response: Response<Profile?>) {
                val profile: Profile? = response.body()
                if (profile != null) {
                    mProfileDetails!!.setValue(profile)
                }
            }

            override fun onFailure(call: Call<Profile?>, t: Throwable) {}
        })
    }
}