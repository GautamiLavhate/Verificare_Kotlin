package com.example.verificarenew.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.DialogFragment
import com.example.verificarenew.R
import com.example.verificarenew.activity.DashboardActivity
import com.example.verificarenew.databinding.FragmentSettingDialogBinding


class SettingDialogFragment : DialogFragment() {

    private lateinit var binding: FragmentSettingDialogBinding
    private var dashboardActivity: DashboardActivity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_setting_dialog, container, false)
        return binding.root
    }

    fun getInstance(): SettingDialogFragment {
        return SettingDialogFragment()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dashboardActivity = activity as DashboardActivity?

        if (dashboardActivity!!.getPreference("sound")) {
            binding.swScanSound.setChecked(true)
        }
        if (dashboardActivity!!.getPreference("nfc")) {
            binding.swScanSound.setChecked(true)
        }

        binding.swScanSound.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            dashboardActivity!!.setPreference(
                "sound",
                isChecked
            )
        })

        binding.swNFC.setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
            dashboardActivity!!.setPreference(
                "nfc",
                isChecked
            )
        })
    }
}