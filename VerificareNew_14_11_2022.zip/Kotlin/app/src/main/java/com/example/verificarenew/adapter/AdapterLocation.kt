package com.example.verificarenew.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.verificarenew.R
import com.example.verificarenew.model.Location


class AdapterLocation(mContext: Context,locationDetails1:List<Location.LocationDetails>) : BaseAdapter() {
    var context: Context = mContext
    val inflater = context.getSystemService(android.content.Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater?
    var locationDetails: List<Location.LocationDetails> = locationDetails1
    override fun getCount(): Int {
        return locationDetails.size
    }

    override fun getItem(position: Int): Any {
        return locationDetails
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        context = parent!!.context
        var holder: ViewHolder? = null
        if (convertView == null) {
            var convertView1 = convertView
            convertView1 = inflater!!.inflate(R.layout.location_list_item, parent, false)
            holder = ViewHolder(convertView1)
            convertView1!!.setTag(holder)
        } else {
            holder = convertView.tag as ViewHolder
        }
        holder.txtplantLocation0.setText(locationDetails[position].name)
        holder.txtplantLocation1.setText(locationDetails[position].plant_name)
        return convertView!!
    }

    internal class ViewHolder(view: View) {
        val txtplantLocation0: TextView
        val txtplantLocation1: TextView

        init {
            txtplantLocation0 = view.findViewById(R.id.txtplantLocation0)
            txtplantLocation1 = view.findViewById(R.id.txtplantLocation1)
        }
    }
}