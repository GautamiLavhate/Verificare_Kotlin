package com.example.verificarenew.activity

import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.verificarenew.R
import com.example.verificarenew.databinding.ActivityScannerBinding
import com.example.verificarenew.fragment.SetCurrentBatch
import com.journeyapps.barcodescanner.CaptureManager
import com.journeyapps.barcodescanner.DecoratedBarcodeView

class ScannerActivity : AppCompatActivity(), DecoratedBarcodeView.TorchListener {
    private lateinit var binding: ActivityScannerBinding
    private var capture: CaptureManager? = null

    private var isFlashLightOn = false
    val RESULT = 140
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_scanner)
        binding.layContentScanner.icManualMode.setOnClickListener(View.OnClickListener { showDialog() })
        binding.back.setOnClickListener(View.OnClickListener { onBackPressed() })


        //set torch listener
        binding.layContentScanner.zxingBarcodeScanner!!.setTorchListener(this)


        //start capture
        capture = CaptureManager(this, binding.layContentScanner.zxingBarcodeScanner)
        capture!!.initializeFromIntent(intent, savedInstanceState)
        capture!!.decode()
    }

    /**
     * Check if the device's camera has a Flashlight.
     *
     * @return true if there is Flashlight, otherwise false.
     */
    open fun hasFlash(): Boolean {
        return applicationContext.packageManager
            .hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
    }

    fun switchFlashlight() {
        isFlashLightOn = if (isFlashLightOn) {
            binding.layContentScanner.zxingBarcodeScanner!!.setTorchOff()
            false
        } else {
            binding.layContentScanner.zxingBarcodeScanner!!.setTorchOn()
            true
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }
    override fun onTorchOn() {

    }

    override fun onTorchOff() {

    }

    override fun onResume() {
        super.onResume()
        capture!!.onResume()
    }

    override fun onPause() {
        super.onPause()
        capture!!.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        capture!!.onDestroy()
    }



    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return binding.layContentScanner.zxingBarcodeScanner!!.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event)
    }

    var isBack = false
    override fun onBackPressed() {
        super.onBackPressed()
    }

    fun showDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.lay_custome_dialog)
        val dailogText = dialog.findViewById<EditText>(R.id.edEnterCode)
        val spinner = dialog.findViewById<Spinner>(R.id.sRegion)
        val dialogButton = dialog.findViewById<Button>(R.id.btSubmit)
        dialogButton.setOnClickListener {
            val re = spinner.selectedItem as String
            val text = dailogText.text.toString()
            if (!text.isEmpty() && spinner.selectedItemPosition != 0) {
                dialog.dismiss()
                if (SetCurrentBatch.getIsDetailsOnly()) {
                    val intent = Intent(baseContext, AssetDetailActivity::class.java)
                    intent.putExtra("Code", text)
                    startActivity(intent)
                } else {
                    CallActivity(text, re)
                }
            } else {
                Toast.makeText(
                    this@ScannerActivity,
                    "Please select reason & add code to proceed...",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        dialog.show()
    }

    private fun CallActivity(code: String, re: String) {
        if (!code.isEmpty()) {
            val i = Intent(this, DetailsViewActivity::class.java)
            i.putExtra("Code", code)
            i.putExtra("isManual", true)
            i.putExtra("r", re)
            startActivity(i)
        } else {
            Toast.makeText(this, "Enter QR Code", Toast.LENGTH_SHORT).show()
        }
    }
}