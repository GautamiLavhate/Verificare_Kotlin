package com.example.verificarenew.util

import android.app.Activity
import android.content.Context
import android.media.MediaPlayer
import com.example.verificarenew.R

class SystemSound {
    private var activity: Context? = null

    fun SystemSound(act: Activity) {
        activity = act.application.applicationContext
    }

    fun SystemSound(act: Context?) {
        activity = act
    }

    fun successTune() {
        try {
            val mp: MediaPlayer = MediaPlayer.create(activity, R.raw.success)
            mp.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun notifyTune() {
        try {
            val mp: MediaPlayer = MediaPlayer.create(activity, R.raw.notify)
            mp.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun errorTune() {
        try {
            val mp: MediaPlayer = MediaPlayer.create(activity, R.raw.error)
            mp.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}