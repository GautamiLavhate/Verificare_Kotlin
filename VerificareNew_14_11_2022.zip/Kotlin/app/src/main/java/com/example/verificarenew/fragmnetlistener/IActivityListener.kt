package com.example.verificarenew.fragmnetlistener

import com.example.verificarenew.model.BatchDetail

interface IActivityListener {
    fun getBatchDetails(batchDetail: BatchDetail)
}