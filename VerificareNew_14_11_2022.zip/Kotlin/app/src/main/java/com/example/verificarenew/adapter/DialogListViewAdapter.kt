package com.example.verificarenew.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.TextView
import com.example.verificarenew.R

class DialogListViewAdapter(context:Context,allItems1:List<String>,onClick1:onClick) : BaseAdapter() {

    private var mContext: Context = context
    private var allItems: List<String> = allItems1
    private var mOnClick: onClick = onClick1

    interface onClick {
        fun onClickEvent(e: Any?, pos: Int)
    }
    override fun getCount(): Int {
        return allItems.size
    }

    override fun getItem(position: Int): Any {
        return position
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var convertView1 = convertView
        if (convertView == null) {

            convertView1 = LayoutInflater.from(mContext)
                .inflate(R.layout.lay_dialog_listview_item, parent, false)
        }
        val textView = convertView1!!.findViewById<TextView>(R.id.tvTitle)
        val linearLayout = convertView1!!.findViewById<LinearLayout>(R.id.llLayout)
        linearLayout.setOnClickListener {
            if (mOnClick != null) {
                mOnClick.onClickEvent(allItems[position], position)
            }
        }
        textView.text = allItems[position]
        return convertView1!!
    }


}