package com.example.verificarenew.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.verificarenew.R
import com.example.verificarenew.adapter.RecyclerHorizantalViewDataAdapter
import com.example.verificarenew.databinding.FragmentDashBoardBinding
import com.example.verificarenew.fragmnetlistener.IActivityListener
import com.example.verificarenew.model.BatchDetail
import com.example.verificarenew.model.Dashboard


class DashBoardFragment : Fragment(), IActivityListener {
    private lateinit var binding:FragmentDashBoardBinding
    private var mViewModel: DashBoardViewModel? = null
    var circularProgressbar: ProgressBar? = null
    var circularnotinuseProgressbar: ProgressBar? = null

    private val list: ArrayList<Dashboard.DashboardDetails.Date> =
        ArrayList<Dashboard.DashboardDetails.Date>()

    var mRecyclerHorizantalViewDataAdapter: RecyclerHorizantalViewDataAdapter? = null
    var isShowToast = false


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_dash_board, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mViewModel = ViewModelProviders.of(this)[DashBoardViewModel::class.java]
        mRecyclerHorizantalViewDataAdapter = RecyclerHorizantalViewDataAdapter(list)
        val horizontalLayoutManager =
            LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
        binding.rcDateTime.setLayoutManager(horizontalLayoutManager)

        binding.rcDateTime.setAdapter(mRecyclerHorizantalViewDataAdapter)

        if (SetCurrentBatch.getInstance().currentBatch != null) {
            getBatchDetails(SetCurrentBatch.getInstance().currentBatch)
        }

    }

    override fun onResume() {
        super.onResume()
        if (SetCurrentBatch.getInstance().currentBatch != null) {
            getBatchDetails(SetCurrentBatch.getInstance().currentBatch)
        }
    }

    override fun getBatchDetails(batchDetail: BatchDetail) {
        binding.btBatchId.setText("Selected Batch :" + batchDetail.batchName)
        binding.tvTotalCountNumber.setText("" + batchDetail.totalQuantity)
        isShowToast = true
        mViewModel!!.DashBoard(batchDetail.batchId, batchDetail.projectId)!!
            .observe(
                viewLifecycleOwner
            ) { dashboardDetails ->
                Log.d("Tag", "onChanged: .$dashboardDetails")
                val data: Dashboard.DashboardDetails? = dashboardDetails.dashboardDetails
                if (data != null) {
                    list.clear()
                    list.addAll(data.getDates())
                    mRecyclerHorizantalViewDataAdapter!!.notifyDataSetChanged()
                    binding.layGridView.tvCompleted.setText("" + data.getCompleted())
                    binding.layGridView.tvAutoModeCount.setText("" + data.getAutoMode())
                    binding.layGridView.tvPendingCount.setText("" + data.getPending())
                    binding.layGridView.tvInUseCount.setText("" + data.getInUse())
                    binding.layGridView.tvManualModeCount.setText("" + data.getManualMode())
                    binding.layGridView.tvNotinUseCount.setText("" + data.getNotInUse())
                    val d: Double = data.getInUsePercentage()
                    val InUsePercentage = d.toInt()
                    val d2: Double = data.getCompletedPercentage()
                    val CompletedPercentage = d2.toInt()
                    circularnotinuseProgressbar!!.progress = InUsePercentage
                    circularProgressbar!!.progress = CompletedPercentage
                    binding.tv.setText("" + data.getCompletedPercentage().toString() + "%")
                    binding.tvCenterNotinUse.setText("" + data.getInUsePercentage().toString() + "%")
                } else {
                    if (isShowToast == true) {
                        Toast.makeText(
                            activity,
                            "" + dashboardDetails.responsemsg,
                            Toast.LENGTH_SHORT
                        ).show()
                        isShowToast = false
                    }
                }
            }
    }
}