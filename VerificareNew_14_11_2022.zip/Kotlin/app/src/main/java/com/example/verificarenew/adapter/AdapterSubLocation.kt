package com.example.verificarenew.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.verificarenew.R
import com.example.verificarenew.model.SubLocation

class AdapterSubLocation(mContext: Context, mSubLocationDetails:List<SubLocation.SubLocationDetails> ): BaseAdapter() {
    var context: Context = mContext
    val inflater = context.getSystemService(android.content.Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater?
    var subLocationDetails: List<SubLocation.SubLocationDetails> = mSubLocationDetails
    override fun getCount(): Int {
        return subLocationDetails.size
    }

    override fun getItem(position: Int): Any {
        return subLocationDetails
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        context = parent!!.context
        var holder: ViewHolder? = null
        if (convertView == null) {
            var convertView1 = convertView
            convertView1= inflater!!.inflate(R.layout.sublocation_list_item, parent, false)
            holder = ViewHolder(convertView1)
            convertView1!!.setTag(holder)
        } else {
            holder = convertView.tag as ViewHolder
        }
        holder.txtplantSubLocation0.setText(subLocationDetails[position].name)
        holder.txtplantSubLocation1.setText(subLocationDetails[position].plant_name)
        holder.txtplantSubLocation2.setText(subLocationDetails[position].location_name)
        return convertView!!
    }

    internal class ViewHolder(view: View) {
        val txtplantSubLocation0: TextView
        val txtplantSubLocation1: TextView
        val txtplantSubLocation2: TextView

        init {
            txtplantSubLocation0 = view.findViewById(R.id.txtplantSubLocation0)
            txtplantSubLocation1 = view.findViewById(R.id.txtplantSubLocation1)
            txtplantSubLocation2 = view.findViewById(R.id.txtplantSubLocation2)
        }
    }
}