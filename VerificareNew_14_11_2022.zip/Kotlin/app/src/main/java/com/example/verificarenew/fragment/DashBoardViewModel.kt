package com.example.verificarenew.fragment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.verificarenew.model.Dashboard
import com.example.verificarenew.network.RetrofitClient
import com.example.verificarenew.network.ServiceApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DashBoardViewModel:ViewModel() {

    private val mBatchDetailsMutableLiveData: MutableLiveData<Dashboard>? =
        MutableLiveData<Dashboard>()

    fun DashBoard(batch_id: String, proj_id: String): LiveData<Dashboard>? {
        if (mBatchDetailsMutableLiveData != null) {
            loadDashBoard(batch_id, proj_id)
        }
        return mBatchDetailsMutableLiveData
    }

    private fun loadDashBoard(batch_id: String, proj_id: String) {
        val request = RetrofitClient.buildService(ServiceApi::class.java)
        val call = request.getDashBoard(batch_id, proj_id)
        call.enqueue(object : Callback<Dashboard?> {
            override fun onResponse(call: Call<Dashboard?>, response: Response<Dashboard?>) {
                val dashboardDetails: Dashboard? = response.body()
                if (dashboardDetails != null) {
                    mBatchDetailsMutableLiveData!!.setValue(dashboardDetails)
                }
            }

            override fun onFailure(call: Call<Dashboard?>, t: Throwable) {}
        })
    }
}